# Changelog

## 1.2.0.6 - 2026-05-19

- Basis teruggezet naar de werkende `1.2.0.3` uit de zip.
- De `1.2.0.4` script-refactor is niet meegenomen, omdat die AJAX 400-errors veroorzaakte.
- WordPress adminbar-offset toegevoegd voor ingelogde beheerders.
- De free shipping / upsell bar blijft onder `#wpadminbar`.
- De Sydney desktop- en mobiele headers schuiven mee onder de adminbar en pluginbar.
- Changelog toegevoegd aan de build.

## 1.2.0.5 - 2026-05-19

- Gebouwd op `1.2.0.4`; vervangen door `1.2.0.6` vanwege regressie in de frontend bar.

## 1.2.0.4 - 2026-05-18

- Frontend JavaScript verplaatst naar losse assetbestanden.
- WooCommerce Blocks dependencies expliciet gedeclareerd.
- Scripts laden via WordPress enqueue in de footer.
- Defensive checks toegevoegd rond WooCommerce Blocks data.
- Backward compatibility met klassieke WooCommerce checkout behouden.

## 1.2.0.3 - 2026-05-18

- Laatste bekende stabiele basis voor de free shipping / upsell bar.

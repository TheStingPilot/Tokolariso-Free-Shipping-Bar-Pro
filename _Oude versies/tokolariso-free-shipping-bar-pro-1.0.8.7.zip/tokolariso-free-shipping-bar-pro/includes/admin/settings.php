<?php

if (!defined('ABSPATH')) {
    exit;
} // END if

add_action(
    'admin_enqueue_scripts',
    'tokolariso_fsb_admin_assets'
);

function tokolariso_fsb_admin_assets(
    $hook
){

    if(
        $hook !== 'woocommerce_page_tokolariso-fsb'
    ){
        return;
    }

    if(
        wp_script_is('wc-enhanced-select', 'registered')
    ){
        wp_enqueue_script('wc-enhanced-select');
    }

    if(
        wp_style_is('woocommerce_admin_styles', 'registered')
    ){
        wp_enqueue_style('woocommerce_admin_styles');
    }
}

function tokolariso_fsb_admin_parse_ids(
    $value
){

    if(
        function_exists('tokolariso_fsb_parse_ids')
    ){
        return tokolariso_fsb_parse_ids($value);
    }

    $parts =
        is_array($value)
        ? $value
        : preg_split(
            '/[\s,;|]+/',
            (string) $value
        );

    $ids = [];

    foreach(
        $parts as $part
    ){
        $id = absint($part);

        if(
            $id > 0
        ){
            $ids[] = $id;
        }
    }

    return array_values(array_unique($ids));
}

function tokolariso_fsb_rules_for_export(){

    if(
        function_exists('tokolariso_fsb_get_upsell_rules')
    ){
        return tokolariso_fsb_get_upsell_rules();
    }

    $rules =
        get_option(
            'tokolariso_fsb_upsell_rules',
            []
        );

    return is_array($rules) ? $rules : [];
}

function tokolariso_fsb_get_product_category_terms(){

    $terms =
        get_terms([
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ]);

    if(
        is_wp_error($terms)
        || empty($terms)
    ){
        return [];
    }

    return $terms;
}

function tokolariso_fsb_render_category_select(
    $name,
    $selected_ids,
    $terms
){

    $selected_ids =
        array_map(
            'absint',
            (array) $selected_ids
        );

    ?>
    <select
        class="tokolariso-fsb-select"
        name="<?php echo esc_attr($name); ?>[]"
        multiple
    >
        <?php foreach($terms as $term) : ?>
            <option
                value="<?php echo esc_attr($term->term_id); ?>"
                <?php selected(in_array((int) $term->term_id, $selected_ids, true)); ?>
            >
                <?php echo esc_html($term->name . ' (#' . $term->term_id . ')'); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <?php
}

function tokolariso_fsb_render_product_select(
    $name,
    $selected_ids
){

    $selected_ids =
        array_map(
            'absint',
            (array) $selected_ids
        );

    ?>
    <select
        class="wc-product-search tokolariso-fsb-select"
        name="<?php echo esc_attr($name); ?>[]"
        multiple
        data-placeholder="<?php esc_attr_e('Zoek producten...', 'tokolariso'); ?>"
        data-action="woocommerce_json_search_products_and_variations"
        data-exclude_type="grouped"
    >
        <?php foreach($selected_ids as $product_id) : ?>
            <?php
            $product =
                wc_get_product($product_id);

            if(
                !$product
            ){
                continue;
            }
            ?>
            <option
                value="<?php echo esc_attr($product_id); ?>"
                selected
            >
                <?php echo esc_html($product->get_formatted_name()); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <?php
}

function tokolariso_fsb_render_rule_card(
    $rule,
    $index,
    $terms
){

    $enabled =
        !empty($rule['enabled']);

    $priority =
        isset($rule['priority'])
        ? (int) $rule['priority']
        : 0;

    ?>
    <section class="tokolariso-fsb-rule" data-rule>
        <div class="tokolariso-fsb-rule__top">
            <label class="tokolariso-fsb-toggle">
                <input
                    type="checkbox"
                    name="upsell_rules[<?php echo esc_attr($index); ?>][enabled]"
                    value="1"
                    <?php checked($enabled); ?>
                >
                <span><?php esc_html_e('Actief', 'tokolariso'); ?></span>
            </label>

            <label class="tokolariso-fsb-priority">
                <span><?php esc_html_e('Prioriteit', 'tokolariso'); ?></span>
                <input
                    type="number"
                    name="upsell_rules[<?php echo esc_attr($index); ?>][priority]"
                    value="<?php echo esc_attr($priority); ?>"
                    step="1"
                >
            </label>

            <button
                type="button"
                class="button-link-delete tokolariso-fsb-remove-rule"
            >
                <?php esc_html_e('Regel verwijderen', 'tokolariso'); ?>
            </button>
        </div>

        <div class="tokolariso-fsb-flow">
            <div class="tokolariso-fsb-panel">
                <h3><?php esc_html_e('Als dit in de winkelwagen zit', 'tokolariso'); ?></h3>

                <label>
                    <span><?php esc_html_e('Broncategorieen', 'tokolariso'); ?></span>
                    <?php
                    tokolariso_fsb_render_category_select(
                        'upsell_rules[' . $index . '][source_categories]',
                        $rule['source_categories'] ?? [],
                        $terms
                    );
                    ?>
                </label>

                <label>
                    <span><?php esc_html_e('Bronproducten', 'tokolariso'); ?></span>
                    <?php
                    tokolariso_fsb_render_product_select(
                        'upsell_rules[' . $index . '][source_products]',
                        $rule['source_products'] ?? []
                    );
                    ?>
                </label>
            </div>

            <div class="tokolariso-fsb-arrow" aria-hidden="true">→</div>

            <div class="tokolariso-fsb-panel">
                <h3><?php esc_html_e('Toon deze upsells', 'tokolariso'); ?></h3>

                <label>
                    <span><?php esc_html_e('Doelcategorieen', 'tokolariso'); ?></span>
                    <?php
                    tokolariso_fsb_render_category_select(
                        'upsell_rules[' . $index . '][target_categories]',
                        $rule['target_categories'] ?? [],
                        $terms
                    );
                    ?>
                </label>

                <label>
                    <span><?php esc_html_e('Doelproducten', 'tokolariso'); ?></span>
                    <?php
                    tokolariso_fsb_render_product_select(
                        'upsell_rules[' . $index . '][target_products]',
                        $rule['target_products'] ?? []
                    );
                    ?>
                </label>
            </div>
        </div>
    </section>
    <?php
}

function tokolariso_fsb_settings_page(){

    if(
        !current_user_can('manage_woocommerce')
    ){
        wp_die(
            esc_html__('Je hebt geen rechten voor deze pagina.', 'tokolariso')
        );
    }

    $message = '';
    $message_type = 'success';

    if(
        (
            isset($_POST['tokolariso_save'])
            || isset($_POST['reset_default_rules'])
        )
        && check_admin_referer(
            'tokolariso_fsb_save_settings',
            'tokolariso_fsb_nonce'
        )
    ){
        update_option(
            'tokolariso_fsb_debug',
            isset($_POST['debug_mode'])
                ? 'yes'
                : 'no'
        );

        update_option(
            'tokolariso_fsb_wpml_source_language',
            'nl',
            false
        );

        if(
            isset($_POST['reset_default_rules'])
        ){
            delete_option('tokolariso_fsb_upsell_rules');
            $message = __('Standaard upsellregels hersteld.', 'tokolariso');
        }elseif(
            !empty($_POST['rules_import'])
        ){
            $decoded =
                json_decode(
                    wp_unslash($_POST['rules_import']),
                    true
                );

            if(
                is_array($decoded)
            ){
                $rules =
                    function_exists('tokolariso_fsb_normalize_upsell_rules')
                    ? tokolariso_fsb_normalize_upsell_rules($decoded)
                    : $decoded;

                update_option(
                    'tokolariso_fsb_upsell_rules',
                    $rules,
                    false
                );

                $message = __('Upsellregels geimporteerd.', 'tokolariso');
            }else{
                $message = __('Import mislukt: JSON is ongeldig.', 'tokolariso');
                $message_type = 'error';
            }
        }else{
            $posted_rules =
                isset($_POST['upsell_rules'])
                && is_array($_POST['upsell_rules'])
                ? wp_unslash($_POST['upsell_rules'])
                : [];

            $rules = [];

            foreach(
                $posted_rules as $posted_rule
            ){
                if(
                    !is_array($posted_rule)
                ){
                    continue;
                }

                $rule = [
                    'enabled' => !empty($posted_rule['enabled']),
                    'priority' => isset($posted_rule['priority'])
                        ? (int) $posted_rule['priority']
                        : 0,
                    'source_categories' => tokolariso_fsb_admin_parse_ids($posted_rule['source_categories'] ?? []),
                    'target_categories' => tokolariso_fsb_admin_parse_ids($posted_rule['target_categories'] ?? []),
                    'source_products' => tokolariso_fsb_admin_parse_ids($posted_rule['source_products'] ?? []),
                    'target_products' => tokolariso_fsb_admin_parse_ids($posted_rule['target_products'] ?? []),
                ];

                if(
                    empty($rule['source_categories'])
                    && empty($rule['source_products'])
                    && empty($rule['target_categories'])
                    && empty($rule['target_products'])
                ){
                    continue;
                }

                $rules[] = $rule;
            }

            if(
                function_exists('tokolariso_fsb_normalize_upsell_rules')
            ){
                $rules =
                    tokolariso_fsb_normalize_upsell_rules($rules);
            }

            update_option(
                'tokolariso_fsb_upsell_rules',
                $rules,
                false
            );

            $message = __('Instellingen opgeslagen.', 'tokolariso');
        }
    }

    $debug =
        get_option(
            'tokolariso_fsb_debug',
            'no'
        );

    $rules =
        tokolariso_fsb_rules_for_export();

    if(
        empty($rules)
    ){
        $rules = [
            [
                'enabled' => true,
                'priority' => 100,
                'source_categories' => [],
                'target_categories' => [],
                'source_products' => [],
                'target_products' => [],
            ],
        ];
    }

    $terms =
        tokolariso_fsb_get_product_category_terms();

    $export =
        wp_json_encode(
            $rules,
            JSON_PRETTY_PRINT
        );

?>

<div class="wrap tokolariso-fsb-admin">

    <h1><?php esc_html_e('Toko Lariso Free Shipping Bar PRO', 'tokolariso'); ?></h1>

    <?php if ($message) : ?>
        <div class="notice notice-<?php echo esc_attr($message_type); ?> is-dismissible">
            <p><?php echo esc_html($message); ?></p>
        </div>
    <?php endif; ?>

    <style>
        .tokolariso-fsb-admin {
            max-width: 1280px;
        }

        .tokolariso-fsb-toolbar,
        .tokolariso-fsb-card,
        .tokolariso-fsb-rule {
            background: #fff;
            border: 1px solid #dcdcde;
            border-radius: 8px;
            box-shadow: 0 1px 2px rgba(0,0,0,.04);
        }

        .tokolariso-fsb-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 16px 18px;
            margin: 18px 0;
        }

        .tokolariso-fsb-toolbar p,
        .tokolariso-fsb-card p {
            margin: 4px 0 0;
            color: #646970;
        }

        .tokolariso-fsb-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .tokolariso-fsb-card {
            padding: 18px;
            margin-top: 20px;
        }

        .tokolariso-fsb-card h2,
        .tokolariso-fsb-rule h3 {
            margin-top: 0;
        }

        .tokolariso-fsb-rule {
            margin: 14px 0;
            padding: 16px;
        }

        .tokolariso-fsb-rule__top {
            display: flex;
            align-items: center;
            gap: 18px;
            padding-bottom: 14px;
            border-bottom: 1px solid #f0f0f1;
        }

        .tokolariso-fsb-toggle,
        .tokolariso-fsb-priority {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }

        .tokolariso-fsb-priority input {
            width: 90px;
        }

        .tokolariso-fsb-remove-rule {
            margin-left: auto;
        }

        .tokolariso-fsb-flow {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 44px minmax(0, 1fr);
            gap: 16px;
            align-items: stretch;
            margin-top: 16px;
        }

        .tokolariso-fsb-panel {
            background: #f6f7f7;
            border: 1px solid #e5e5e5;
            border-radius: 8px;
            padding: 14px;
        }

        .tokolariso-fsb-panel label {
            display: block;
            margin-top: 14px;
            font-weight: 600;
        }

        .tokolariso-fsb-panel label > span {
            display: block;
            margin-bottom: 6px;
        }

        .tokolariso-fsb-select,
        .tokolariso-fsb-panel .select2,
        .tokolariso-fsb-panel .selectWoo {
            width: 100% !important;
            max-width: 100%;
        }

        .tokolariso-fsb-arrow {
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2271b1;
            font-size: 28px;
            font-weight: 700;
        }

        .tokolariso-fsb-import-export {
            display: grid;
            grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
            gap: 18px;
        }

        .tokolariso-fsb-admin textarea {
            min-height: 220px;
        }

        @media (max-width: 960px) {
            .tokolariso-fsb-toolbar,
            .tokolariso-fsb-rule__top,
            .tokolariso-fsb-actions {
                align-items: flex-start;
                flex-direction: column;
            }

            .tokolariso-fsb-flow,
            .tokolariso-fsb-import-export {
                grid-template-columns: 1fr;
            }

            .tokolariso-fsb-arrow {
                display: none;
            }
        }
    </style>

    <form method="post">

        <?php wp_nonce_field('tokolariso_fsb_save_settings', 'tokolariso_fsb_nonce'); ?>

        <div class="tokolariso-fsb-toolbar">
            <div>
                <h2><?php esc_html_e('Upsellregels', 'tokolariso'); ?></h2>
                <p><?php esc_html_e('Maak regels op basis van categorieen of specifieke producten. Hogere prioriteit wordt eerst getoond.', 'tokolariso'); ?></p>
                <p><?php esc_html_e('WPML-brontaal voor regels: Nederlands (nl).', 'tokolariso'); ?></p>
            </div>

            <div class="tokolariso-fsb-actions">
                <label>
                    <input
                        type="checkbox"
                        name="debug_mode"
                        <?php checked($debug, 'yes'); ?>
                    >
                    <?php esc_html_e('Debug logging', 'tokolariso'); ?>
                </label>

                <button
                    type="button"
                    class="button"
                    id="tokolariso-fsb-add-rule"
                >
                    <?php esc_html_e('Nieuwe regel', 'tokolariso'); ?>
                </button>

                <button
                    class="button button-primary"
                    type="submit"
                    name="tokolariso_save"
                    value="1"
                >
                    <?php esc_html_e('Opslaan', 'tokolariso'); ?>
                </button>
            </div>
        </div>

        <div id="tokolariso-fsb-rules">
            <?php
            $row_index = 0;

            foreach(
                $rules as $rule
            ){
                tokolariso_fsb_render_rule_card(
                    $rule,
                    $row_index,
                    $terms
                );

                $row_index++;
            }
            ?>
        </div>

        <div class="tokolariso-fsb-card">
            <h2><?php esc_html_e('Import / export', 'tokolariso'); ?></h2>
            <p><?php esc_html_e('Export bevat dezelfde ID-structuur als eerdere versies. Import vervangt alle huidige regels.', 'tokolariso'); ?></p>

            <div class="tokolariso-fsb-import-export">
                <label>
                    <strong><?php esc_html_e('Export', 'tokolariso'); ?></strong>
                    <textarea readonly class="large-text code"><?php echo esc_textarea($export); ?></textarea>
                </label>

                <label>
                    <strong><?php esc_html_e('Import', 'tokolariso'); ?></strong>
                    <textarea
                        name="rules_import"
                        class="large-text code"
                        placeholder="<?php esc_attr_e('Plak JSON import hier', 'tokolariso'); ?>"
                    ></textarea>
                </label>
            </div>

            <p class="tokolariso-fsb-actions">
                <button
                    class="button"
                    type="submit"
                    name="tokolariso_save"
                    value="1"
                >
                    <?php esc_html_e('Import uitvoeren', 'tokolariso'); ?>
                </button>

                <button
                    class="button"
                    type="submit"
                    name="reset_default_rules"
                    value="1"
                    onclick="return confirm('<?php echo esc_js(__('Standaard upsellregels herstellen?', 'tokolariso')); ?>');"
                >
                    <?php esc_html_e('Standaardregels herstellen', 'tokolariso'); ?>
                </button>
            </p>
        </div>

    </form>

    <template id="tokolariso-fsb-rule-template">
        <?php
        tokolariso_fsb_render_rule_card(
            [
                'enabled' => true,
                'priority' => 0,
                'source_categories' => [],
                'target_categories' => [],
                'source_products' => [],
                'target_products' => [],
            ],
            '__INDEX__',
            $terms
        );
        ?>
    </template>

    <script>
    jQuery(function($){

        let nextIndex =
            <?php echo (int) $row_index; ?>;

        function enhance(context) {

            const root =
                context ? $(context) : $(document);

            root.find('.tokolariso-fsb-select').each(function(){

                const select =
                    $(this);

                if (
                    select.hasClass('enhanced')
                    ||
                    select.data('select2')
                    ||
                    select.data('selectWoo')
                ) {
                    return;
                }

                if (
                    select.hasClass('wc-product-search')
                ) {
                    $(document.body).trigger('wc-enhanced-select-init');
                    return;
                }

                if ($.fn.selectWoo) {
                    select.selectWoo({
                        width: '100%'
                    });
                    return;
                }

                if ($.fn.select2) {
                    select.select2({
                        width: '100%'
                    });
                }
            });
        }

        enhance(document);

        $('#tokolariso-fsb-add-rule').on('click', function(){

            const template =
                $('#tokolariso-fsb-rule-template')
                    .html()
                    .split('__INDEX__')
                    .join(String(nextIndex));

            const node =
                $(template);

            $('#tokolariso-fsb-rules')
                .append(node);

            nextIndex++;
            enhance(node);
        });

        $(document).on('click', '.tokolariso-fsb-remove-rule', function(){

            $(this)
                .closest('[data-rule]')
                .remove();
        });
    });
    </script>

</div>

<?php

} // END function tokolariso_fsb_settings_page()

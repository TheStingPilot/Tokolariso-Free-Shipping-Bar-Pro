# Changelog

## 1.2.0.5 - 2026-05-19

- WordPress adminbar-offset toegevoegd voor ingelogde beheerders.
- De free shipping / upsell bar blijft nu onder `#wpadminbar`.
- De Sydney desktop- en mobiele headers schuiven mee onder de bar.
- Dit changelogbestand toegevoegd aan de plugin-build.

## 1.2.0.4 - 2026-05-18

- Frontend JavaScript verplaatst naar losse assetbestanden.
- WooCommerce Blocks dependencies expliciet gedeclareerd.
- Scripts laden via WordPress enqueue in de footer.
- Defensive checks toegevoegd rond WooCommerce Blocks data.
- Backward compatibility met klassieke WooCommerce checkout behouden.

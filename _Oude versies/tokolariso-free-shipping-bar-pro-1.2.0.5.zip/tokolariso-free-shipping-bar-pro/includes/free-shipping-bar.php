<?php

/*
 * FREE SHIPPING BAR
 * TOKO LARISO
 * VERSIE: ZONDAG 10 MEI 2026
 * CSS AANGEPAST 11 MEI 2026
 * v
 * Versie 1.0.3:
 *  - LOCATIEBUG
 * 
 * =========================================================
 * VERSIE 1.0.4
 * =========================================================
 * 
 *  - Prijs alleen hoger dan 0,01
 *  - Aantal producten in de slider is nu 15
 *  - Met pijltjes.
 *  - CSS issues op mobiel.
 * 
 * =========================================================
 * VERSIE 1.0.5
 * =========================================================
 * 
 *  - Met smart upsell rules 
 *  - BUG opgelost: in de winkelwagen producten toevoegen 
 *        geen update van de winkelwagen is opgelost.
 * 
 * =========================================================
 * VERSIE 1.0.6
 * =========================================================
 *
 * - Sydney cart counter volledig gestabiliseerd
 * - WooCommerce Blocks sync verbeterd
 * - MutationObserver verbeterd
 * - Counter badge HTML veilig gemaakt
 * - Debug logging opgeschoond
 * - END comments toegevoegd
 * - Onderhoudbaarheid sterk verbeterd
 */

/* =========================================================
 * AJAX URL
========================================================= */

add_action(
    'wp_enqueue_scripts',
    'tokolariso_fsb_enqueue_frontend_assets',
    20
);

function tokolariso_fsb_frontend_script_dependencies(){

    /*
     * Declare the WooCommerce Blocks data dependencies explicitly.
     * This prevents WooCommerce 10.x from reporting that wc.wcBlocksData
     * was accessed by an inline or unknown script without dependencies.
     */

    $dependencies = [
        'jquery',
        'wp-data',
        'wp-element',
        'wp-dom-ready',
        'wc-settings',
    ];

    if (
        wp_script_is('wc-blocks-data-store', 'registered')
        || wp_script_is('wc-blocks-data-store', 'enqueued')
    ) {
        $dependencies[] = 'wc-blocks-data-store';
    } // END if

    return $dependencies;
} // END function tokolariso_fsb_frontend_script_dependencies()

function tokolariso_fsb_enqueue_frontend_assets(){

    if(
        is_admin()
        || is_order_received_page()
    ){
        return;
    } // END if

    $version = '1.2.0.5';

    wp_register_style(
        'tokolariso-fsb-frontend',
        false,
        [],
        $version
    );

    wp_enqueue_style(
        'tokolariso-fsb-frontend'
    );

    wp_add_inline_style(
        'tokolariso-fsb-frontend',
        tokolariso_fsb_frontend_css()
    );

    wp_register_script(
        'tokolariso-fsb-frontend',
        TOKOLARISO_FSB_URL . 'assets/js/free-shipping-bar.js',
        tokolariso_fsb_frontend_script_dependencies(),
        $version,
        true
    );

    /*
     * Localized data is attached to the registered handle, so it prints
     * immediately before the footer script and inherits the same dependency
     * context instead of running as an anonymous inline script in wp_head.
     */

    wp_enqueue_script(
        'tokolariso-fsb-frontend'
    );

    wp_localize_script(
        'tokolariso-fsb-frontend',
        'fsb_ajax',
        [
            'url' => admin_url('admin-ajax.php'),
            'debug' => get_option('tokolariso_fsb_debug', 'no') === 'yes',
            'progress_nonce' => wp_create_nonce('tokolariso_fsb_progress'),
            'cart_nonce' => wp_create_nonce('tokolariso_fsb_cart'),
            'is_logged_in' => is_user_logged_in(),
            'use_customer_address' => (
                is_user_logged_in()
                && function_exists('is_account_page')
                && is_account_page()
            ),
            'fragments_url' => WC_AJAX::get_endpoint('get_refreshed_fragments'),
            'i18n' => [
                'add_to_cart' => __('+ Toevoegen', 'tokolariso'),
                'added' => __('✓ Toegevoegd', 'tokolariso'),
                'prev' => __('Vorige', 'tokolariso'),
                'next' => __('Volgende', 'tokolariso'),
            ],
        ]
    );

    wp_register_script(
        'tokolariso-fsb-subtotals',
        TOKOLARISO_FSB_URL . 'assets/js/subtotals.js',
        array_merge(
            tokolariso_fsb_frontend_script_dependencies(),
            ['tokolariso-fsb-frontend']
        ),
        $version,
        true
    );

    wp_enqueue_script(
        'tokolariso-fsb-subtotals'
    );
} // END function tokolariso_fsb_enqueue_frontend_assets()

function tokolariso_fsb_frontend_css(){

    /*
     * WordPress adminbar staat fixed boven de site voor ingelogde beheerders.
     * De free shipping / upsell bar en de Sydney headers gebruiken dezelfde
     * offset, zodat de complete header-stack onder de adminbar blijft.
     */

    return '
:root {
    --fsb-height: 0px;
    --fsb-admin-offset: 0px;
}

body.admin-bar {
    --fsb-admin-offset: 32px;
}

@media screen and (max-width: 782px) {
    body.admin-bar {
        --fsb-admin-offset: 46px;
    }
}

#free-shipping-bar {
    top: var(--fsb-admin-offset, 0px) !important;
}

#masthead,
#masthead-mobile {
    top: calc(var(--fsb-admin-offset, 0px) + var(--fsb-height, 0px)) !important;
}
';
} // END function tokolariso_fsb_frontend_css()

if(
    !function_exists('str_contains')
){
    function str_contains(
        $haystack,
        $needle
    ){
        return $needle === ''
            || strpos($haystack, $needle) !== false;
    } // END function str_contains()
} // END if

function tokolariso_fsb_debug_log(
    $message,
    $context = null
){

    if(
        get_option('tokolariso_fsb_debug', 'no') !== 'yes'
    ){
        return;
    } // END if

    if(
        $context !== null
    ){
        $message .= ' ' . print_r($context, true);
    } // END if

    error_log($message);
} // END function tokolariso_fsb_debug_log()

function tokolariso_fsb_default_upsell_rules(){

    return [
        [
            'enabled' => true,
            'priority' => 100,
            'source_categories' => [59],
            'target_categories' => [1880,35,30,32,3480,3477],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 90,
            'source_categories' => [32],
            'target_categories' => [34,35,30],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 80,
            'source_categories' => [204],
            'target_categories' => [172],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 70,
            'source_categories' => [208],
            'target_categories' => [34],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 60,
            'source_categories' => [172],
            'target_categories' => [3480],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 50,
            'source_categories' => [157],
            'target_categories' => [21,224,2019,19,177,38,1857],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 40,
            'source_categories' => [3478],
            'target_categories' => [3477,3479,3480],
            'source_products' => [],
            'target_products' => [],
        ],
    ];
} // END function tokolariso_fsb_default_upsell_rules()

function tokolariso_fsb_parse_ids(
    $value
){

    if(
        is_array($value)
    ){
        $parts = $value;
    }else{
        $parts = preg_split(
            '/[\s,;|]+/',
            (string) $value
        );
    } // END if

    $ids = [];

    foreach(
        $parts as $part
    ){
        $id = absint($part);

        if(
            $id > 0
        ){
            $ids[] = $id;
        } // END if
    } // END foreach

    return array_values(array_unique($ids));
} // END function tokolariso_fsb_parse_ids()

function tokolariso_fsb_normalize_upsell_rules(
    $rules
){

    if(
        !is_array($rules)
    ){
        return [];
    } // END if

    $normalized = [];

    foreach(
        $rules as $rule
    ){
        if(
            !is_array($rule)
        ){
            continue;
        } // END if

        $normalized[] = [
            'enabled' => !isset($rule['enabled']) || (bool) $rule['enabled'],
            'priority' => isset($rule['priority']) ? (int) $rule['priority'] : 0,
            'source_categories' => tokolariso_fsb_parse_ids($rule['source_categories'] ?? []),
            'target_categories' => tokolariso_fsb_parse_ids($rule['target_categories'] ?? []),
            'source_products' => tokolariso_fsb_parse_ids($rule['source_products'] ?? []),
            'target_products' => tokolariso_fsb_parse_ids($rule['target_products'] ?? []),
        ];
    } // END foreach

    usort(
        $normalized,
        function($a, $b){
            return ($b['priority'] <=> $a['priority']);
        }
    );

    return $normalized;
} // END function tokolariso_fsb_normalize_upsell_rules()

function tokolariso_fsb_make_default_rules_bidirectional(
    $rules
){

    $extra_rules = [];

    foreach(
        $rules as $rule
    ){
        foreach(
            $rule['source_categories'] ?? [] as $source_category
        ){
            foreach(
                $rule['target_categories'] ?? [] as $target_category
            ){
                $extra_rules[] = [
                    'enabled' => true,
                    'priority' => max(1, ((int) ($rule['priority'] ?? 0)) - 1),
                    'source_categories' => [$target_category],
                    'target_categories' => [$source_category],
                    'source_products' => [],
                    'target_products' => [],
                ];
            } // END foreach
        } // END foreach
    } // END foreach

    return array_merge(
        $rules,
        $extra_rules
    );
} // END function tokolariso_fsb_make_default_rules_bidirectional()

function tokolariso_fsb_get_upsell_rules(){

    $rules =
        get_option(
            'tokolariso_fsb_upsell_rules',
            null
        );

    if(
        empty($rules)
        || !is_array($rules)
    ){
        $rules =
            tokolariso_fsb_make_default_rules_bidirectional(
                tokolariso_fsb_default_upsell_rules()
            );
    } // END if

    return tokolariso_fsb_normalize_upsell_rules($rules);
} // END function tokolariso_fsb_get_upsell_rules()

function tokolariso_fsb_get_current_language(){

    if(
        has_filter('wpml_current_language')
    ){
        $language =
            apply_filters(
                'wpml_current_language',
                null
            );

        if(
            $language
        ){
            return $language;
        } // END if
    } // END if

    return tokolariso_fsb_get_source_language();
} // END function tokolariso_fsb_get_current_language()

function tokolariso_fsb_get_source_language(){

    $language =
        get_option(
            'tokolariso_fsb_wpml_source_language',
            'nl'
        );

    $language =
        apply_filters(
            'tokolariso_fsb_wpml_source_language',
            $language
        );

    return $language ? $language : 'nl';
} // END function tokolariso_fsb_get_source_language()

function tokolariso_fsb_translate_object_id(
    $id,
    $type,
    $language
){

    if(
        has_filter('wpml_object_id')
    ){
        $translated =
            apply_filters(
                'wpml_object_id',
                $id,
                $type,
                true,
                $language
            );

        if(
            $translated
        ){
            return (int) $translated;
        } // END if
    } // END if

    return (int) $id;
} // END function tokolariso_fsb_translate_object_id()

function tokolariso_fsb_id_in_wcpos_list(
    $value,
    $product_id
){

    if(
        is_array($value)
    ){
        foreach(
            $value as $item
        ){
            if(
                tokolariso_fsb_id_in_wcpos_list(
                    $item,
                    $product_id
                )
            ){
                return true;
            } // END if
        } // END foreach

        return false;
    } // END if

    return absint($value) === absint($product_id);
} // END function tokolariso_fsb_id_in_wcpos_list()

function tokolariso_fsb_wcpos_visibility_has_pos_only(
    $value,
    $product_id,
    $key_hint = ''
){

    if(
        is_array($value)
    ){
        foreach(
            $value as $key => $item
        ){
            $key_string =
                strtolower(
                    (string) $key
                );

            $combined_key =
                trim($key_hint . ' ' . $key_string);

            if(
                (
                    $key_string === (string) absint($product_id)
                    || $key === absint($product_id)
                )
                && is_string($item)
                && $item === 'pos_only'
            ){
                return true;
            } // END if

            if(
                strpos($combined_key, 'pos_only') !== false
                &&
                tokolariso_fsb_id_in_wcpos_list(
                    $item,
                    $product_id
                )
            ){
                return true;
            } // END if

            if(
                tokolariso_fsb_wcpos_visibility_has_pos_only(
                    $item,
                    $product_id,
                    $combined_key
                )
            ){
                return true;
            } // END if
        } // END foreach
    } // END if

    return false;
} // END function tokolariso_fsb_wcpos_visibility_has_pos_only()

function tokolariso_fsb_is_wcpos_pos_only_product_id(
    $product_id
){

    $product_id =
        absint($product_id);

    if(
        !$product_id
    ){
        return false;
    } // END if

    $legacy_visibility =
        get_post_meta(
            $product_id,
            '_pos_visibility',
            true
        );

    if(
        $legacy_visibility === 'pos_only'
    ){
        return true;
    } // END if

    $visibility_options =
        get_option(
            'woocommerce_pos_settings_visibility',
            []
        );

    if(
        empty($visibility_options)
    ){
        return false;
    } // END if

    if(
        !empty($visibility_options['products']['pos_only']['ids'])
        &&
        is_array($visibility_options['products']['pos_only']['ids'])
        &&
        in_array(
            $product_id,
            array_map('absint', $visibility_options['products']['pos_only']['ids']),
            true
        )
    ){
        return true;
    } // END if

    if(
        !empty($visibility_options['variations']['pos_only']['ids'])
        &&
        is_array($visibility_options['variations']['pos_only']['ids'])
        &&
        in_array(
            $product_id,
            array_map('absint', $visibility_options['variations']['pos_only']['ids']),
            true
        )
    ){
        return true;
    } // END if

    return tokolariso_fsb_wcpos_visibility_has_pos_only(
        $visibility_options,
        $product_id
    );
} // END function tokolariso_fsb_is_wcpos_pos_only_product_id()

function tokolariso_fsb_is_wcpos_pos_only_product(
    $product
){

    if(
        !$product
    ){
        return false;
    } // END if

    if(
        tokolariso_fsb_is_wcpos_pos_only_product_id(
            $product->get_id()
        )
    ){
        return true;
    } // END if

    $parent_id =
        $product->get_parent_id();

    if(
        $parent_id
        &&
        tokolariso_fsb_is_wcpos_pos_only_product_id($parent_id)
    ){
        return true;
    } // END if

    return false;
} // END function tokolariso_fsb_is_wcpos_pos_only_product()

function tokolariso_fsb_get_cart_context(){

    $category_ids = [];
    $product_ids = [];

    foreach(
        WC()->cart->get_cart() as $cart_item
    ){
        $product_id = absint($cart_item['product_id'] ?? 0);
        $variation_id = absint($cart_item['variation_id'] ?? 0);

        if(
            $product_id
        ){
            $product_ids[] = $product_id;
            $product_ids[] =
                tokolariso_fsb_translate_object_id(
                    $product_id,
                    'product',
                    tokolariso_fsb_get_source_language()
                );
        } // END if

        if(
            $variation_id
        ){
            $product_ids[] = $variation_id;
            $product_ids[] =
                tokolariso_fsb_translate_object_id(
                    $variation_id,
                    'product_variation',
                    tokolariso_fsb_get_source_language()
                );
        } // END if

        $terms =
            get_the_terms(
                $product_id,
                'product_cat'
            );

        if(
            empty($terms)
            || is_wp_error($terms)
        ){
            continue;
        } // END if

        foreach(
            $terms as $term
        ){
            $category_ids[] =
                tokolariso_fsb_translate_object_id(
                    $term->term_id,
                    'product_cat',
                    tokolariso_fsb_get_source_language()
                );
        } // END foreach
    } // END foreach

    return [
        'category_ids' => array_values(array_unique(array_map('absint', $category_ids))),
        'product_ids' => array_values(array_unique(array_map('absint', $product_ids))),
    ];
} // END function tokolariso_fsb_get_cart_context()

function tokolariso_fsb_prepare_upsell_product(
    $product
){

    if(
        !$product
        || tokolariso_fsb_is_wcpos_pos_only_product($product)
        || !$product->is_in_stock()
        || (float) $product->get_price() <= 0.01
    ){
        return null;
    } // END if

    $image_id =
        $product->get_image_id();

    if(
        !$image_id
        && $product->get_parent_id()
    ){
        $image_id =
            get_post_thumbnail_id(
                $product->get_parent_id()
            );
    } // END if

    return [
        'id' => $product->get_id(),
        'name' => $product->get_name(),
        'price' => html_entity_decode(
            wp_strip_all_tags(
                wc_price(
                    $product->get_price()
                )
            )
        ),
        'image' => wp_get_attachment_image_url(
            $image_id,
            'thumbnail'
        ),
    ];
} // END function tokolariso_fsb_prepare_upsell_product()

function tokolariso_fsb_get_upsells(
    $limit = 15
){

    if(
        is_null(WC()->cart)
        && function_exists('wc_load_cart')
    ){
        wc_load_cart();
    } // END if

    if(
        !WC()->cart
        || WC()->cart->is_empty()
    ){
        return [];
    } // END if

    $language =
        tokolariso_fsb_get_current_language();

    $context =
        tokolariso_fsb_get_cart_context();

    $exclude_ids =
        $context['product_ids'];

    $target_categories = [];
    $target_products = [];
    $candidate_priority = [];
    $category_priority = [];

    foreach(
        tokolariso_fsb_get_upsell_rules() as $rule
    ){
        if(
            empty($rule['enabled'])
        ){
            continue;
        } // END if

        $category_match =
            !empty($rule['source_categories'])
            && array_intersect(
                $rule['source_categories'],
                $context['category_ids']
            );

        $product_match =
            !empty($rule['source_products'])
            && array_intersect(
                $rule['source_products'],
                $context['product_ids']
            );

        if(
            !$category_match
            && !$product_match
        ){
            continue;
        } // END if

        foreach(
            $rule['target_categories'] as $category_id
        ){
            $translated_id =
                tokolariso_fsb_translate_object_id(
                    $category_id,
                    'product_cat',
                    $language
                );

            $target_categories[] = $translated_id;
            $category_priority[$translated_id] =
                max(
                    $category_priority[$translated_id] ?? PHP_INT_MIN,
                    (int) $rule['priority']
                );
        } // END foreach

        foreach(
            $rule['target_products'] as $product_id
        ){
            $translated_id =
                tokolariso_fsb_translate_object_id(
                    $product_id,
                    'product',
                    $language
                );

            if(
                in_array($translated_id, $exclude_ids, true)
            ){
                continue;
            } // END if

            $target_products[] = $translated_id;
            $candidate_priority[$translated_id] =
                max(
                    $candidate_priority[$translated_id] ?? PHP_INT_MIN,
                    (int) $rule['priority']
                );
        } // END foreach
    } // END foreach

    $products_by_id = [];

    foreach(
        array_values(array_unique($target_products)) as $product_id
    ){
        $product =
            wc_get_product($product_id);

        if(
            !$product
        ){
            continue;
        } // END if

        if(
            $product->is_type('variable')
        ){
            foreach(
                $product->get_children() as $variation_id
            ){
                if(
                    in_array($variation_id, $exclude_ids, true)
                ){
                    continue;
                } // END if

                $variation =
                    wc_get_product($variation_id);

                if(
                    $variation
                ){
                    $products_by_id[$variation->get_id()] = $variation;
                    $candidate_priority[$variation->get_id()] =
                        $candidate_priority[$product->get_id()] ?? 0;
                } // END if
            } // END foreach
        }else{
            $products_by_id[$product->get_id()] = $product;
        } // END if
    } // END foreach

    $target_categories =
        array_values(
            array_unique(
                array_filter(
                    array_map('absint', $target_categories)
                )
            )
        );

    if(
        $target_categories
    ){
        $query = new WC_Product_Query([
            'status' => 'publish',
            'limit' => 40,
            'stock_status' => 'instock',
            'exclude' => $exclude_ids,
            'return' => 'objects',
            'tax_query' => [
                [
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $target_categories,
                    'operator' => 'IN',
                ],
            ],
        ]);

        foreach(
            $query->get_products() as $product
        ){
            if(
                $product->is_type('variable')
            ){
                foreach(
                    $product->get_children() as $variation_id
                ){
                    if(
                        in_array($variation_id, $exclude_ids, true)
                    ){
                        continue;
                    } // END if

                    $variation =
                        wc_get_product($variation_id);

                    if(
                        $variation
                    ){
                        $products_by_id[$variation->get_id()] = $variation;
                    } // END if
                } // END foreach
            }else{
                $products_by_id[$product->get_id()] = $product;
            } // END if

            $terms =
                get_the_terms(
                    $product->get_id(),
                    'product_cat'
                );

            if(
                empty($terms)
                || is_wp_error($terms)
            ){
                continue;
            } // END if

            foreach(
                $terms as $term
            ){
                $term_id =
                    tokolariso_fsb_translate_object_id(
                        $term->term_id,
                        'product_cat',
                        $language
                    );

                if(
                    !isset($category_priority[$term_id])
                ){
                    continue;
                } // END if

                $matched_priority =
                    $category_priority[$term_id];

                $candidate_priority[$product->get_id()] =
                    max(
                        $candidate_priority[$product->get_id()] ?? PHP_INT_MIN,
                        $matched_priority
                    );

                if(
                    $product->is_type('variable')
                ){
                    foreach(
                        $product->get_children() as $variation_id
                    ){
                        $candidate_priority[$variation_id] =
                            max(
                                $candidate_priority[$variation_id] ?? PHP_INT_MIN,
                                $matched_priority
                            );
                    } // END foreach
                } // END if
            } // END foreach
        } // END foreach
    } // END if

    $products =
        array_values($products_by_id);

    usort(
        $products,
        function($a, $b) use ($candidate_priority){
            $a_priority =
                $candidate_priority[$a->get_id()] ?? 0;

            $b_priority =
                $candidate_priority[$b->get_id()] ?? 0;

            if(
                $a_priority === $b_priority
            ){
                return strcasecmp(
                    $a->get_name(),
                    $b->get_name()
                );
            } // END if

            return $b_priority <=> $a_priority;
        }
    );

    $upsells = [];

    foreach(
        $products as $product
    ){
        $prepared =
            tokolariso_fsb_prepare_upsell_product($product);

        if(
            !$prepared
        ){
            continue;
        } // END if

        $upsells[] = $prepared;

        if(
            count($upsells) >= $limit
        ){
            break;
        } // END if
    } // END foreach

    return $upsells;
} // END function tokolariso_fsb_get_upsells()

function tokolariso_fsb_get_customer_address(){

    $address = [
        'country' => '',
        'postcode' => '',
        'city' => '',
        'state' => '',
    ];

    $customer =
        function_exists('WC') && WC()->customer
        ? WC()->customer
        : null;

    if ($customer) {

        $address['country'] =
            $customer->get_shipping_country()
            ?: $customer->get_billing_country()
            ?: '';

        $address['postcode'] =
            $customer->get_shipping_postcode()
            ?: $customer->get_billing_postcode()
            ?: '';

        $address['city'] =
            $customer->get_shipping_city()
            ?: $customer->get_billing_city()
            ?: '';

        $address['state'] =
            $customer->get_shipping_state()
            ?: $customer->get_billing_state()
            ?: '';
    } // END if

    $user_id =
        get_current_user_id();

    if ($user_id > 0) {

        if (!$address['country']) {

            $address['country'] =
                get_user_meta($user_id, 'shipping_country', true)
                ?: get_user_meta($user_id, 'billing_country', true)
                ?: '';
        } // END if

        if (!$address['postcode']) {

            $address['postcode'] =
                get_user_meta($user_id, 'shipping_postcode', true)
                ?: get_user_meta($user_id, 'billing_postcode', true)
                ?: '';
        } // END if

        if (!$address['city']) {

            $address['city'] =
                get_user_meta($user_id, 'shipping_city', true)
                ?: get_user_meta($user_id, 'billing_city', true)
                ?: '';
        } // END if

        if (!$address['state']) {

            $address['state'] =
                get_user_meta($user_id, 'shipping_state', true)
                ?: get_user_meta($user_id, 'billing_state', true)
                ?: '';
        } // END if
    } // END if

    $address['country'] =
        $address['country'] ?: 'NL';

    return array_map(
        'sanitize_text_field',
        $address
    );
} // END function tokolariso_fsb_get_customer_address()



/* =========================================================
 * CENTRAL SHIPPING DATA
========================================================= */

function tokolariso_get_shipping_data(
    $package = []
){

    /*
     * WooCommerce check
     */

    if(
        !class_exists('WooCommerce')
    ){
        return [
            'zone' => null,
            'minimum' => 0,
            'has_free_shipping' => false
        ];
    } // END if

    /*
     * Cart check
     */

    if(
        is_null(WC()->cart)
    ){
        wc_load_cart();
    } // END if

    /*
     * Default package
     */

    if(
        empty($package)
    ){

        $address =
            tokolariso_fsb_get_customer_address();

        $package = [

            'destination' => [

                'country'  => $address['country'],
                'postcode' => $address['postcode'],
                'city'     => $address['city'],
                'state'    => $address['state'],
            ]
        ];
    } // END if

    /*
     * Shipping zone
     */

$zone =
    wc_get_shipping_zone($package);

    if(
        !$zone
    ){
        return [
            'zone' => null,
            'minimum' => 0,
            'has_free_shipping' => false
        ];
    } // END if

    /*
     * Find lowest free shipping threshold
     */

    $min = 0;

    foreach(
        $zone->get_shipping_methods(true)
        as $method
    ){

        /*
         * Native WooCommerce free shipping
         */

        if(
            $method->id === 'free_shipping'
            && $method->enabled === 'yes'
        ){

            $minimum =
                isset($method->min_amount)
                ? (float) $method->min_amount
                : 0;

            if(
                $minimum > 0
                && (
                    $min <= 0
                    || $minimum < $min
                )
            ){
                $min = $minimum;
            } // END if

            continue;
        } // END if

        /*
         * WBSNG
         */

        if(
            $method->id !== 'wbsng'
            || $method->enabled !== 'yes'
        ){
            continue;
        } // END if

        $config =
            get_option(
                'wbsng_' .
                $method->instance_id .
                '_config'
            );

        tokolariso_fsb_debug_log(
            'WBSNG CONFIG:',
            $config
        );

        tokolariso_fsb_debug_log(
            'WBSNG METHOD ID:',
            $method->instance_id
        );

        tokolariso_fsb_debug_log(
            'WBSNG METHOD OBJECT:',
            $method
        );
		
        if(
            empty($config['methods'])
            || !is_array($config['methods'])
        ){
            continue;
        } // END if

        foreach(
            $config['methods']
            as $shipping_method
        ){

            if(
                empty($shipping_method['rules'])
                || !is_array($shipping_method['rules'])
            ){
                continue;
            } // END if

            foreach(
    $shipping_method['rules']
    as $rule
){

    tokolariso_fsb_debug_log(
        'FREE SHIPPING RULE:',
        $rule
    );

/*
 * Gratis verzending detecteren
 */

$is_free_shipping = false;

/*
 * Expliciet gratis
 */

if(
    isset($rule['charge'])
    && isset($rule['charge']['rate'])
){

    $rate =
        trim(
            (string) $rule['charge']['rate']
        );

    if(
        $rate === '0'
        || $rate === '0.0'
    ){
        $is_free_shipping = true;
    } // END if
} // END if

/*
 * OF:
 * geen charge aanwezig
 * = gratis verzending
 */

if(
    !isset($rule['charge'])
){
    $is_free_shipping = true;
} // END if

if(
    !$is_free_shipping
){
    continue;
} // END if

/*
 * Minimum threshold
 */

$minimum =
    isset($rule['price']['min'])
    ? (float) $rule['price']['min']
    : 0;

    tokolariso_fsb_debug_log(
        'FREE SHIPPING MINIMUM:',
        $minimum
    );

    if(
        $minimum <= 0
    ){
        continue;
    } // END if

    /*
     * Save lowest threshold
     */

    if(
        $min <= 0
        || $minimum < $min
    ){

        $min = $minimum;

        tokolariso_fsb_debug_log(
            'FREE SHIPPING FOUND:',
            $min
        );
    } // END if

            } // END foreach
        } // END foreach
    } // END foreach

$debug_methods = [];

foreach(
    $zone->get_shipping_methods(true)
    as $method
){
$config =
    get_option(
        'wbsng_' .
        $method->instance_id .
        '_config'
    );
$debug_methods[] = [

    'id' => $method->id ?? '',

    'instance_id' => $method->instance_id ?? '',

    'title' => $method->title ?? '',

    'enabled' => $method->enabled ?? '',

    'config' => json_decode(
    json_encode($config),
    true
)
];
} // END foreach
	
return [

    'zone' => [],

    'minimum' => $min,

    'has_free_shipping' => $min > 0,

    'debug_methods' => $debug_methods
];
} // END function tokolariso_get_shipping_data()


/* =========================================================
 * FILTER SHIPPING RATES
========================================================= */

add_filter(
    'woocommerce_package_rates',
    'tokolariso_force_wbsng_free_shipping',
    9999,
    2
);

function tokolariso_force_wbsng_free_shipping(
    $rates,
    $package
){

    if (
        !WC()->cart
    ) {
        return $rates;
    } // END if

    $shipping_data =
        tokolariso_get_shipping_data(
            $package
        );

    $minimum =
        (float) (
            $shipping_data['minimum']
            ?? 0
        );

    if (
        $minimum <= 0
    ) {
        return $rates;
    } // END if

    $total =
        (float) WC()->cart->get_subtotal()
        +
        (float) WC()->cart->get_subtotal_tax();

    if (
        $total < $minimum
    ) {
        return $rates;
    } // END if

    foreach (
        $rates as $rate_id => $rate
    ) {

        /*
         * Alleen WBSNG
         */

        if (
            $rate->method_id !== 'wbsng'
        ) {
            continue;
        } // END if

        /*
         * Hard override
         */

        $rate->cost = 0;

        /*
         * Taxes reset
         */

        $rate->taxes = [];

        /*
         * Label aanpassen
         */

        if (
            !str_contains(
                strtolower($rate->label),
                'gratis'
            )
        ) {

            $rate->label .= ' (Gratis)';
        } // END if

        /*
         * Meta data
         */

        $rate->add_meta_data(
            'tokolariso_free_shipping',
            'yes',
            true
        );

        /*
         * Overschrijven
         */

        $rates[$rate_id] = $rate;

    } // END foreach

    return $rates;

} // END function

/* =========================================================
 * FRONTEND BAR
========================================================= */



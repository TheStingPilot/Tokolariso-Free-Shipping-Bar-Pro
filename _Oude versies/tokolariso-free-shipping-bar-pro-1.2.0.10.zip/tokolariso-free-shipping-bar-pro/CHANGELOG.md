# Changelog

## 1.2.0.10 - 2026-05-20

- Added fallback upsells when no rule-based products are found.
- Added a shorter mobile progress message: "Nog X tot gratis verzending. Bespaar Y".
- Added automatic font-size fitting for the mobile progress message.
- Tightened the Sydney mobile header logo limits for narrow screens.

## 1.2.0.9 - 2026-05-20

- Added dynamic shipping savings to the progress message: "Add X for free shipping and save Y".
- Shipping savings are calculated from WooCommerce shipping rates for the detected zone and include shipping tax.
- No shipping amounts are hardcoded.
- Kept the mobile progress message on a single line with overflow ellipsis.
- Translated the changelog to English.

## 1.2.0.8 - 2026-05-19

- Adjusted the Sydney mobile header from the plugin CSS.
- Limited the mobile logo width and height so the menu bar is no longer stretched.
- Prevented mobile header icons from shrinking unnecessarily.
- Scoped the change to `#masthead-mobile` and screens up to 1024px wide.

## 1.2.0.7 - 2026-05-19

- Made the progress AJAX endpoint read-only tolerant so expired or cached nonces no longer cause `400 Bad Request`.
- Kept the add-to-cart nonce validation for write actions.
- Moved `fsb_ajax` to the footer directly before the frontend bar code.
- Added a dependency correction for the known Mollie/Inpsyde handle `inpsyde-blocks`.
- Kept the stable `1.2.0.3` base and did not reintroduce the broken external JS refactor from `1.2.0.4/1.2.0.5`.

## 1.2.0.6 - 2026-05-19

- Restored the working `1.2.0.3` base from the zip archive.
- Excluded the `1.2.0.4` script refactor because it caused AJAX 400 errors.
- Added a WordPress admin bar offset for logged-in administrators.
- Kept the free shipping / upsell bar below `#wpadminbar`.
- Made the Sydney desktop and mobile headers move below the admin bar and plugin bar.
- Added this changelog to the build.

## 1.2.0.5 - 2026-05-19

- Built on `1.2.0.4`; superseded by `1.2.0.6` because of a frontend bar regression.

## 1.2.0.4 - 2026-05-18

- Moved frontend JavaScript to separate asset files.
- Declared WooCommerce Blocks dependencies explicitly.
- Loaded scripts through the WordPress enqueue system in the footer.
- Added defensive checks around WooCommerce Blocks data.
- Preserved backward compatibility with the classic WooCommerce checkout.

## 1.2.0.3 - 2026-05-18

- Last known stable base for the free shipping / upsell bar.

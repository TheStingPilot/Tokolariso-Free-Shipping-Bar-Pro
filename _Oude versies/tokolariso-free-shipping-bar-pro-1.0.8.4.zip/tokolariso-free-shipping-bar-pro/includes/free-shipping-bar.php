<?php

/*
 * FREE SHIPPING BAR
 * TOKO LARISO
 * VERSIE: ZONDAG 10 MEI 2026
 * CSS AANGEPAST 11 MEI 2026
 * v
 * Versie 1.0.3:
 *  - LOCATIEBUG
 * 
 * =========================================================
 * VERSIE 1.0.4
 * =========================================================
 * 
 *  - Prijs alleen hoger dan 0,01
 *  - Aantal producten in de slider is nu 15
 *  - Met pijltjes.
 *  - CSS issues op mobiel.
 * 
 * =========================================================
 * VERSIE 1.0.5
 * =========================================================
 * 
 *  - Met smart upsell rules 
 *  - BUG opgelost: in de winkelwagen producten toevoegen 
 *        geen update van de winkelwagen is opgelost.
 * 
 * =========================================================
 * VERSIE 1.0.6
 * =========================================================
 *
 * - Sydney cart counter volledig gestabiliseerd
 * - WooCommerce Blocks sync verbeterd
 * - MutationObserver verbeterd
 * - Counter badge HTML veilig gemaakt
 * - Debug logging opgeschoond
 * - END comments toegevoegd
 * - Onderhoudbaarheid sterk verbeterd
 */

/* =========================================================
 * AJAX URL
========================================================= */

add_action('wp_head', function () {
?>
<script>
var fsb_ajax = {

    url: '<?php echo admin_url('admin-ajax.php'); ?>',

    debug: <?php echo get_option('tokolariso_fsb_debug', 'no') === 'yes' ? 'true' : 'false'; ?>,
	
    fragments_url:
    '<?php echo WC_AJAX::get_endpoint( "get_refreshed_fragments" ); ?>',

    i18n: {

        add_to_cart:
            '<?php echo esc_js(
                __('+ Toevoegen', 'tokolariso')
            ); ?>',

        added:
            '<?php echo esc_js(
                __('✓ Toegevoegd', 'tokolariso')
            ); ?>'
    }
};
</script>
<?php
});

if(
    !function_exists('str_contains')
){
    function str_contains(
        $haystack,
        $needle
    ){
        return $needle === ''
            || strpos($haystack, $needle) !== false;
    }
}

function tokolariso_fsb_debug_log(
    $message,
    $context = null
){

    if(
        get_option('tokolariso_fsb_debug', 'no') !== 'yes'
    ){
        return;
    }

    if(
        $context !== null
    ){
        $message .= ' ' . print_r($context, true);
    }

    error_log($message);
}

function tokolariso_fsb_default_upsell_rules(){

    return [
        [
            'enabled' => true,
            'priority' => 100,
            'source_categories' => [59],
            'target_categories' => [1880,35,30,32,3480,3477],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 90,
            'source_categories' => [32],
            'target_categories' => [34,35,30],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 80,
            'source_categories' => [204],
            'target_categories' => [172],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 70,
            'source_categories' => [208],
            'target_categories' => [34],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 60,
            'source_categories' => [172],
            'target_categories' => [3480],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 50,
            'source_categories' => [157],
            'target_categories' => [21,224,2019,19,177,38,1857],
            'source_products' => [],
            'target_products' => [],
        ],
        [
            'enabled' => true,
            'priority' => 40,
            'source_categories' => [3478],
            'target_categories' => [3477,3479,3480],
            'source_products' => [],
            'target_products' => [],
        ],
    ];
}

function tokolariso_fsb_parse_ids(
    $value
){

    if(
        is_array($value)
    ){
        $parts = $value;
    }else{
        $parts = preg_split(
            '/[\s,;|]+/',
            (string) $value
        );
    }

    $ids = [];

    foreach(
        $parts as $part
    ){
        $id = absint($part);

        if(
            $id > 0
        ){
            $ids[] = $id;
        }
    }

    return array_values(array_unique($ids));
}

function tokolariso_fsb_normalize_upsell_rules(
    $rules
){

    if(
        !is_array($rules)
    ){
        return [];
    }

    $normalized = [];

    foreach(
        $rules as $rule
    ){
        if(
            !is_array($rule)
        ){
            continue;
        }

        $normalized[] = [
            'enabled' => !isset($rule['enabled']) || (bool) $rule['enabled'],
            'priority' => isset($rule['priority']) ? (int) $rule['priority'] : 0,
            'source_categories' => tokolariso_fsb_parse_ids($rule['source_categories'] ?? []),
            'target_categories' => tokolariso_fsb_parse_ids($rule['target_categories'] ?? []),
            'source_products' => tokolariso_fsb_parse_ids($rule['source_products'] ?? []),
            'target_products' => tokolariso_fsb_parse_ids($rule['target_products'] ?? []),
        ];
    }

    usort(
        $normalized,
        function($a, $b){
            return ($b['priority'] <=> $a['priority']);
        }
    );

    return $normalized;
}

function tokolariso_fsb_make_default_rules_bidirectional(
    $rules
){

    $extra_rules = [];

    foreach(
        $rules as $rule
    ){
        foreach(
            $rule['source_categories'] ?? [] as $source_category
        ){
            foreach(
                $rule['target_categories'] ?? [] as $target_category
            ){
                $extra_rules[] = [
                    'enabled' => true,
                    'priority' => max(1, ((int) ($rule['priority'] ?? 0)) - 1),
                    'source_categories' => [$target_category],
                    'target_categories' => [$source_category],
                    'source_products' => [],
                    'target_products' => [],
                ];
            }
        }
    }

    return array_merge(
        $rules,
        $extra_rules
    );
}

function tokolariso_fsb_get_upsell_rules(){

    $rules =
        get_option(
            'tokolariso_fsb_upsell_rules',
            null
        );

    if(
        empty($rules)
        || !is_array($rules)
    ){
        $rules =
            tokolariso_fsb_make_default_rules_bidirectional(
                tokolariso_fsb_default_upsell_rules()
            );
    }

    return tokolariso_fsb_normalize_upsell_rules($rules);
}

function tokolariso_fsb_get_current_language(){

    if(
        has_filter('wpml_current_language')
    ){
        $language =
            apply_filters(
                'wpml_current_language',
                null
            );

        if(
            $language
        ){
            return $language;
        }
    }

    return 'nl';
}

function tokolariso_fsb_translate_object_id(
    $id,
    $type,
    $language
){

    if(
        has_filter('wpml_object_id')
    ){
        $translated =
            apply_filters(
                'wpml_object_id',
                $id,
                $type,
                true,
                $language
            );

        if(
            $translated
        ){
            return (int) $translated;
        }
    }

    return (int) $id;
}

function tokolariso_fsb_get_cart_context(){

    $category_ids = [];
    $product_ids = [];

    foreach(
        WC()->cart->get_cart() as $cart_item
    ){
        $product_id = absint($cart_item['product_id'] ?? 0);
        $variation_id = absint($cart_item['variation_id'] ?? 0);

        if(
            $product_id
        ){
            $product_ids[] = $product_id;
        }

        if(
            $variation_id
        ){
            $product_ids[] = $variation_id;
        }

        $terms =
            get_the_terms(
                $product_id,
                'product_cat'
            );

        if(
            empty($terms)
            || is_wp_error($terms)
        ){
            continue;
        }

        foreach(
            $terms as $term
        ){
            $category_ids[] =
                tokolariso_fsb_translate_object_id(
                    $term->term_id,
                    'product_cat',
                    'nl'
                );
        }
    }

    return [
        'category_ids' => array_values(array_unique(array_map('absint', $category_ids))),
        'product_ids' => array_values(array_unique(array_map('absint', $product_ids))),
    ];
}

function tokolariso_fsb_prepare_upsell_product(
    $product
){

    if(
        !$product
        || !$product->is_in_stock()
        || (float) $product->get_price() <= 0.01
    ){
        return null;
    }

    $image_id =
        $product->get_image_id();

    if(
        !$image_id
        && $product->get_parent_id()
    ){
        $image_id =
            get_post_thumbnail_id(
                $product->get_parent_id()
            );
    }

    return [
        'id' => $product->get_id(),
        'name' => $product->get_name(),
        'price' => html_entity_decode(
            wp_strip_all_tags(
                wc_price(
                    $product->get_price()
                )
            )
        ),
        'image' => wp_get_attachment_image_url(
            $image_id,
            'thumbnail'
        ),
    ];
}

function tokolariso_fsb_get_upsells(
    $limit = 15
){

    if(
        is_null(WC()->cart)
        && function_exists('wc_load_cart')
    ){
        wc_load_cart();
    }

    if(
        !WC()->cart
        || WC()->cart->is_empty()
    ){
        return [];
    }

    $language =
        tokolariso_fsb_get_current_language();

    $context =
        tokolariso_fsb_get_cart_context();

    $exclude_ids =
        $context['product_ids'];

    $target_categories = [];
    $target_products = [];
    $candidate_priority = [];
    $category_priority = [];

    foreach(
        tokolariso_fsb_get_upsell_rules() as $rule
    ){
        if(
            empty($rule['enabled'])
        ){
            continue;
        }

        $category_match =
            !empty($rule['source_categories'])
            && array_intersect(
                $rule['source_categories'],
                $context['category_ids']
            );

        $product_match =
            !empty($rule['source_products'])
            && array_intersect(
                $rule['source_products'],
                $context['product_ids']
            );

        if(
            !$category_match
            && !$product_match
        ){
            continue;
        }

        foreach(
            $rule['target_categories'] as $category_id
        ){
            $translated_id =
                tokolariso_fsb_translate_object_id(
                    $category_id,
                    'product_cat',
                    $language
                );

            $target_categories[] = $translated_id;
            $category_priority[$translated_id] =
                max(
                    $category_priority[$translated_id] ?? PHP_INT_MIN,
                    (int) $rule['priority']
                );
        }

        foreach(
            $rule['target_products'] as $product_id
        ){
            $translated_id =
                tokolariso_fsb_translate_object_id(
                    $product_id,
                    'product',
                    $language
                );

            if(
                in_array($translated_id, $exclude_ids, true)
            ){
                continue;
            }

            $target_products[] = $translated_id;
            $candidate_priority[$translated_id] =
                max(
                    $candidate_priority[$translated_id] ?? PHP_INT_MIN,
                    (int) $rule['priority']
                );
        }
    }

    $products_by_id = [];

    foreach(
        array_values(array_unique($target_products)) as $product_id
    ){
        $product =
            wc_get_product($product_id);

        if(
            !$product
        ){
            continue;
        }

        if(
            $product->is_type('variable')
        ){
            foreach(
                $product->get_children() as $variation_id
            ){
                if(
                    in_array($variation_id, $exclude_ids, true)
                ){
                    continue;
                }

                $variation =
                    wc_get_product($variation_id);

                if(
                    $variation
                ){
                    $products_by_id[$variation->get_id()] = $variation;
                    $candidate_priority[$variation->get_id()] =
                        $candidate_priority[$product->get_id()] ?? 0;
                }
            }
        }else{
            $products_by_id[$product->get_id()] = $product;
        }
    }

    $target_categories =
        array_values(
            array_unique(
                array_filter(
                    array_map('absint', $target_categories)
                )
            )
        );

    if(
        $target_categories
    ){
        $query = new WC_Product_Query([
            'status' => 'publish',
            'limit' => 40,
            'stock_status' => 'instock',
            'exclude' => $exclude_ids,
            'return' => 'objects',
            'tax_query' => [
                [
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $target_categories,
                    'operator' => 'IN',
                ],
            ],
        ]);

        foreach(
            $query->get_products() as $product
        ){
            if(
                $product->is_type('variable')
            ){
                foreach(
                    $product->get_children() as $variation_id
                ){
                    if(
                        in_array($variation_id, $exclude_ids, true)
                    ){
                        continue;
                    }

                    $variation =
                        wc_get_product($variation_id);

                    if(
                        $variation
                    ){
                        $products_by_id[$variation->get_id()] = $variation;
                    }
                }
            }else{
                $products_by_id[$product->get_id()] = $product;
            }

            $terms =
                get_the_terms(
                    $product->get_id(),
                    'product_cat'
                );

            if(
                empty($terms)
                || is_wp_error($terms)
            ){
                continue;
            }

            foreach(
                $terms as $term
            ){
                $term_id =
                    tokolariso_fsb_translate_object_id(
                        $term->term_id,
                        'product_cat',
                        $language
                    );

                if(
                    !isset($category_priority[$term_id])
                ){
                    continue;
                }

                $matched_priority =
                    $category_priority[$term_id];

                $candidate_priority[$product->get_id()] =
                    max(
                        $candidate_priority[$product->get_id()] ?? PHP_INT_MIN,
                        $matched_priority
                    );

                if(
                    $product->is_type('variable')
                ){
                    foreach(
                        $product->get_children() as $variation_id
                    ){
                        $candidate_priority[$variation_id] =
                            max(
                                $candidate_priority[$variation_id] ?? PHP_INT_MIN,
                                $matched_priority
                            );
                    }
                }
            }
        }
    }

    $products =
        array_values($products_by_id);

    usort(
        $products,
        function($a, $b) use ($candidate_priority){
            $a_priority =
                $candidate_priority[$a->get_id()] ?? 0;

            $b_priority =
                $candidate_priority[$b->get_id()] ?? 0;

            if(
                $a_priority === $b_priority
            ){
                return strcasecmp(
                    $a->get_name(),
                    $b->get_name()
                );
            }

            return $b_priority <=> $a_priority;
        }
    );

    $upsells = [];

    foreach(
        $products as $product
    ){
        $prepared =
            tokolariso_fsb_prepare_upsell_product($product);

        if(
            !$prepared
        ){
            continue;
        }

        $upsells[] = $prepared;

        if(
            count($upsells) >= $limit
        ){
            break;
        }
    }

    return $upsells;
}



/* =========================================================
 * CENTRAL SHIPPING DATA
========================================================= */

function tokolariso_get_shipping_data(
    $package = []
){

    /*
     * WooCommerce check
     */

    if(
        !class_exists('WooCommerce')
    ){
        return [
            'zone' => null,
            'minimum' => 0,
            'has_free_shipping' => false
        ];
    }

    /*
     * Cart check
     */

    if(
        is_null(WC()->cart)
    ){
        wc_load_cart();
    }

    /*
     * Default package
     */

    if(
        empty($package)
    ){

        $customer =
            WC()->customer;

        $package = [

            'destination' => [

                'country'  => $customer ? $customer->get_shipping_country() : '',
                'postcode' => $customer ? $customer->get_shipping_postcode() : '',
                'city'     => $customer ? $customer->get_shipping_city() : '',
                'state'    => $customer ? $customer->get_shipping_state() : '',
            ]
        ];
    }

    /*
     * Shipping zone
     */

$zone =
    wc_get_shipping_zone($package);

    if(
        !$zone
    ){
        return [
            'zone' => null,
            'minimum' => 0,
            'has_free_shipping' => false
        ];
    }

    /*
     * Find lowest free shipping threshold
     */

    $min = 0;

    foreach(
        $zone->get_shipping_methods(true)
        as $method
    ){

        /*
         * Native WooCommerce free shipping
         */

        if(
            $method->id === 'free_shipping'
            && $method->enabled === 'yes'
        ){

            $minimum =
                isset($method->min_amount)
                ? (float) $method->min_amount
                : 0;

            if(
                $minimum > 0
                && (
                    $min <= 0
                    || $minimum < $min
                )
            ){
                $min = $minimum;
            }

            continue;
        }

        /*
         * WBSNG
         */

        if(
            $method->id !== 'wbsng'
            || $method->enabled !== 'yes'
        ){
            continue;
        }

        $config =
            get_option(
                'wbsng_' .
                $method->instance_id .
                '_config'
            );

        tokolariso_fsb_debug_log(
            'WBSNG CONFIG:',
            $config
        );

        tokolariso_fsb_debug_log(
            'WBSNG METHOD ID:',
            $method->instance_id
        );

        tokolariso_fsb_debug_log(
            'WBSNG METHOD OBJECT:',
            $method
        );
		
        if(
            empty($config['methods'])
            || !is_array($config['methods'])
        ){
            continue;
        }

        foreach(
            $config['methods']
            as $shipping_method
        ){

            if(
                empty($shipping_method['rules'])
                || !is_array($shipping_method['rules'])
            ){
                continue;
            }

            foreach(
    $shipping_method['rules']
    as $rule
){

    tokolariso_fsb_debug_log(
        'FREE SHIPPING RULE:',
        $rule
    );

/*
 * Gratis verzending detecteren
 */

$is_free_shipping = false;

/*
 * Expliciet gratis
 */

if(
    isset($rule['charge'])
    && isset($rule['charge']['rate'])
){

    $rate =
        trim(
            (string) $rule['charge']['rate']
        );

    if(
        $rate === '0'
        || $rate === '0.0'
    ){
        $is_free_shipping = true;
    }
}

/*
 * OF:
 * geen charge aanwezig
 * = gratis verzending
 */

if(
    !isset($rule['charge'])
){
    $is_free_shipping = true;
}

if(
    !$is_free_shipping
){
    continue;
}

/*
 * Minimum threshold
 */

$minimum =
    isset($rule['price']['min'])
    ? (float) $rule['price']['min']
    : 0;

    tokolariso_fsb_debug_log(
        'FREE SHIPPING MINIMUM:',
        $minimum
    );

    if(
        $minimum <= 0
    ){
        continue;
    }

    /*
     * Save lowest threshold
     */

    if(
        $min <= 0
        || $minimum < $min
    ){

        $min = $minimum;

        tokolariso_fsb_debug_log(
            'FREE SHIPPING FOUND:',
            $min
        );
    }

            }
        }
    }

$debug_methods = [];

foreach(
    $zone->get_shipping_methods(true)
    as $method
){
$config =
    get_option(
        'wbsng_' .
        $method->instance_id .
        '_config'
    );
$debug_methods[] = [

    'id' => $method->id ?? '',

    'instance_id' => $method->instance_id ?? '',

    'title' => $method->title ?? '',

    'enabled' => $method->enabled ?? '',

    'config' => json_decode(
    json_encode($config),
    true
)
];
}
	
return [

    'zone' => [],

    'minimum' => $min,

    'has_free_shipping' => $min > 0,

    'debug_methods' => $debug_methods
];
}


/* =========================================================
 * FILTER SHIPPING RATES
========================================================= */

add_filter(
    'woocommerce_package_rates',
    'tokolariso_force_wbsng_free_shipping',
    9999,
    2
);

function tokolariso_force_wbsng_free_shipping(
    $rates,
    $package
){

    if (
        !WC()->cart
    ) {
        return $rates;
    }

    $shipping_data =
        tokolariso_get_shipping_data(
            $package
        );

    $minimum =
        (float) (
            $shipping_data['minimum']
            ?? 0
        );

    if (
        $minimum <= 0
    ) {
        return $rates;
    }

    $total =
        (float) WC()->cart->get_subtotal()
        +
        (float) WC()->cart->get_subtotal_tax();

    if (
        $total < $minimum
    ) {
        return $rates;
    }

    foreach (
        $rates as $rate_id => $rate
    ) {

        /*
         * Alleen WBSNG
         */

        if (
            $rate->method_id !== 'wbsng'
        ) {
            continue;
        }

        /*
         * Hard override
         */

        $rate->cost = 0;

        /*
         * Taxes reset
         */

        $rate->taxes = [];

        /*
         * Label aanpassen
         */

        if (
            !str_contains(
                strtolower($rate->label),
                'gratis'
            )
        ) {

            $rate->label .= ' (Gratis)';
        }

        /*
         * Meta data
         */

        $rate->add_meta_data(
            'tokolariso_free_shipping',
            'yes',
            true
        );

        /*
         * Overschrijven
         */

        $rates[$rate_id] = $rate;

    } // END foreach

    return $rates;

} // END function

/* =========================================================
 * FRONTEND BAR
========================================================= */

add_action('wp_footer', function () {

    if(
        is_admin()
        || is_order_received_page()
    ){
        return;
    }

?>

<style>

/* =========================================================
   ROOT
========================================================= */

:root {

    --fsb-height: 60px;
}

/* =========================================
   CART COUNTER PULSE
========================================= */

.count-number.pulse {

    animation:
        tokolariso-cart-pulse
        0.35s ease;
}

@keyframes tokolariso-cart-pulse {

    0% {

        transform: scale(1);
    }

    50% {

        transform: scale(1.35);
    }

    100% {

        transform: scale(1);
    }
}
	
	
/* =========================================================
   FREE SHIPPING BAR
========================================================= */

#free-shipping-bar {

    position: sticky;

    top: 0;

    width: 100%;

    z-index: 1000;

    background: #111;
    color: #fff;

    padding: 14px 20px;

    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    box-sizing: border-box;
}

/* =========================================================
   DESKTOP HEADER
========================================================= */

#masthead {

    position: sticky !important;

    top: var(--fsb-height) !important;

    z-index: 990 !important;

    overflow: visible !important;
}

/* =========================================================
   MOBILE HEADER
========================================================= */

#masthead-mobile {

    position: sticky !important;

    top: var(--fsb-height) !important;

    z-index: 990 !important;

    overflow: visible !important;
}

/* =========================================================
   HERO / HEADER IMAGE
========================================================= */

.sydney-hero-area,
.custom-header,
.page-header,
.header-image {

    position: relative;

    z-index: 1;
}

/* =========================================================
   MESSAGE
========================================================= */

#free-shipping-bar .msg {

    width: 100%;

    text-align: center;

    font-size: clamp(13px, 1.4vw, 20px);

    font-weight: 700;

    line-height: 1.2;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* =========================================================
   PROGRESS
========================================================= */

#free-shipping-bar .progress {

    width: 100%;
    max-width: 700px;

    height: 6px;

    margin-top: 10px;

    background: rgba(255,255,255,.2);

    border-radius: 999px;

    overflow: hidden;
}

#free-shipping-bar .bar {

    width: 0%;
    height: 100%;

    min-width: 6px;

    transition: width .4s ease;

    background: linear-gradient(
        90deg,
        #4CAF50,
        #8BC34A
    );
}

#free-shipping-bar .bar.complete {

    background: linear-gradient(
        90deg,
        #43A047,
        #2E7D32
    );
}

/* =========================================================
   UPSELL WRAPPER
========================================================= */

#free-shipping-bar .upsells-wrapper {

    width: 100%;

    display: flex;
    align-items: center;

    gap: 14px;

    margin-top: 16px;
}

#free-shipping-bar .upsells {

    flex: 1;

    display: flex;

    gap: 14px;

    overflow: hidden;
}

/* =========================================================
   ARROWS
========================================================= */

#free-shipping-bar .upsells-arrow {

    width: 42px;
    height: 42px;

    border: 0;

    border-radius: 999px;

    background: rgba(255,255,255,.12);

    color: #fff;

    font-size: 28px;

    cursor: pointer;

    flex-shrink: 0;

    display: flex;
    align-items: center;
    justify-content: center;
}

/* =========================================================
   CARD
========================================================= */

#free-shipping-bar .upsell {

    flex: 0 0 calc((100% - 28px) / 3);

    min-width: 0;

    display: flex;
    align-items: center;

    gap: 12px;

    padding: 10px 12px;

    border-radius: 16px;

    background: rgba(255,255,255,.08);

    border: 1px solid rgba(255,255,255,.08);

    backdrop-filter: blur(8px);
}

#free-shipping-bar .upsell img {

    width: 52px;
    height: 52px;

    object-fit: cover;

    border-radius: 999px;

    background: #fff;

    flex-shrink: 0;
}

#free-shipping-bar .upsell-info {

    flex: 1;

    min-width: 0;

    display: flex;
    flex-direction: column;
}

#free-shipping-bar .upsell-title {

    color: #fff;

    font-size: 13px;

    font-weight: 700;

    line-height: 1.25;
}

#free-shipping-bar .upsell-price {

    margin-top: 4px;

    color: rgba(255,255,255,.75);

    font-size: 12px;
}

#free-shipping-bar .upsell-btn {

    border: 0;

    border-radius: 999px;

    padding: 9px 14px;

    background: linear-gradient(
        135deg,
        #4CAF50,
        #66BB6A
    );

    color: #fff;

    font-size: 12px;

    font-weight: 700;

    white-space: nowrap;

    cursor: pointer;

    flex-shrink: 0;
}

/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 1024px) {

    /* =========================================
       SIDEBAR CART
    ========================================= */

    #sidebar-cart,
    #sidebar-cart.is-open {

        z-index: 4000 !important;
    }

    .cart-overlay.show-overlay {

        z-index: 3999 !important;
    }

    /* =========================================
       MOBILE MENU
    ========================================= */

    .offcanvas-menu,
    .offcanvas-menu-wrap,
    .sydney-offcanvas-menu,
    .mobile-menu-container {

        z-index: 3000 !important;
    }

    /* =========================================
       FREE SHIPPING BAR
    ========================================= */

    #free-shipping-bar {

        padding: 10px 12px;
    }

    #free-shipping-bar .msg {

        font-size: clamp(12px, 3.3vw, 17px);
    }

    /* =========================================
       MOBILE UPSELLS
    ========================================= */

    #free-shipping-bar .upsells-arrow {

        display: none;
    }

    #free-shipping-bar .upsells {

        width: 100%;

        display: flex !important;

        flex-wrap: nowrap !important;

        overflow-x: auto !important;

        overflow-y: hidden !important;

        gap: 12px;

        margin-top: 16px;

        padding-bottom: 4px;

        -webkit-overflow-scrolling: touch;

        scrollbar-width: none;

        scroll-snap-type: x mandatory;
    }

    #free-shipping-bar .upsells::-webkit-scrollbar {

        display: none;
    }

    #free-shipping-bar .upsell {

        width: 100%;

        min-width: 100%;

        max-width: 100%;

        flex: 0 0 auto;

        scroll-snap-align: center;
    }
}

</style>
	
<script>

(function(){

const DEBUG = !!(window.fsb_ajax && window.fsb_ajax.debug);

function debugLog(...args) {

    if (DEBUG) {

        console.log(...args);

    } /* END if (DEBUG) */

} /* END function debugLog() */

function hideBar() {

    const existingBar =
        document.getElementById(
            'free-shipping-bar'
        );

    if (existingBar) {

        existingBar.remove();
    }

    document.documentElement.style.setProperty(
        '--fsb-height',
        '0px'
    );
}

function escapeHtml(value) {

    return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function safeImage(value) {

    const url = String(value || '');

    if (
        url.startsWith('http://')
        ||
        url.startsWith('https://')
        ||
        url.startsWith('/')
    ) {
        return url;
    }

    return '';
}

function getCartItemCount(cart) {

    const directCount =
        cart?.itemsCount
        ?? cart?.items_count
        ?? cart?.item_count;

    if (
        directCount !== undefined
        &&
        directCount !== null
        &&
        !Number.isNaN(Number(directCount))
    ) {
        return Number(directCount);
    }

    if (Array.isArray(cart?.items)) {

        return cart.items.reduce(function(total, item){

            const quantity =
                Number(
                    item?.quantity
                    ?? item?.qty
                    ?? 1
                );

            return total + (
                Number.isNaN(quantity)
                ? 0
                : quantity
            );

        }, 0);
    }

    return 0;
}

function setCartCounterValue(count) {

    const selectors = [
        '.cart-count .count',
        '.cart-count .count-number',
        '.cart-contents .count',
        '.site-header-cart .count',
        '.header-cart .count',
        '.sydney-header-cart .count',
        '.menu-item-cart .count',
        '.wc-block-mini-cart__badge',
        '[class*="cart"] .count-number',
        '[class*="cart"] .count'
    ];

    const badges =
        document.querySelectorAll(
            selectors.join(',')
        );

    badges.forEach(function(badge){

        badge.textContent = String(count);

        badge.classList.remove(
            'pulse'
        );

        void badge.offsetWidth;

        badge.classList.add(
            'pulse'
        );
    });
}

	/*
 * Sydney cart counter sync
 */

function syncSydneyCartCounter() {

    if (
        !window.wp ||
        !wp.data
    ) {
        return;
    } // END function syncSydneyCartCounter()

    /*
     * Kleine delay zodat
     * Woo Blocks klaar is
     */

    setTimeout(() => {

        let cart;

        try {

            cart =
                wp.data
                .select('wc/store/cart')
                .getCartData();

        } catch (e) {

            console.error(
                'STORE API ERROR',
                e
            );

            return;

        } // END try/catch

        /*
         * Aantal producten
         */

const count =
    getCartItemCount(cart);

        /*
         * Zoek bestaande badge
         */

        let badge =
            document.querySelector(
                '.cart-count .count'
            );

        /*
         * Sydney fallback:
         * oudere themes
         */

        if (!badge) {

            badge =
                document.querySelector(
                    '.cart-count .count-number'
                );

        } // END if (!badge)

        /*
         * Geen badge gevonden?
         * Dan zelf aanmaken
         */

        if (!badge) {

            const wrapper =
                document.querySelector(
                    '.cart-count'
                );

            if (!wrapper) {
                return;
            } // END if

            badge =
                document.createElement(
                    'span'
                );

            badge.className =
                'count';

            wrapper.appendChild(
                badge
            );

        } // END if (!badge create)

        /*
         * Alleen nummer vervangen
         */

        badge.textContent = count;
        setCartCounterValue(count);

		if (count <= 0) {

          hideBar();

        } // END if (count <= 0)

        /*
         * Pulse animatie
         */

        badge.classList.remove(
            'pulse'
        );

        void badge.offsetWidth;

        badge.classList.add(
            'pulse'
        );

        /*
         * Debug logging
         */

        if (DEBUG) {

            console.log(
                'COUNTER UPDATED:',
                count
            );

        } // END if (DEBUG)

    }, 500);

    /* END setTimeout */

} // END function syncSydneyCartCounter()
	
function initBar() {

    if (typeof fsb_ajax === 'undefined') {
        return;
    } // END if

    let loading = false;
    let storeSubscribed = false;

    const isCartPage =
        document.body.classList.contains(
            'woocommerce-cart'
        );

    function whenCartStoreReady(callback) {

        let tries = 0;

        const timer =
            setInterval(function(){

                tries++;

                let hasStore = false;

                try {

                    hasStore = !!(
                        window.wp
                        &&
                        wp.data
                        &&
                        wp.data.select
                        &&
                        wp.data.select('wc/store/cart')
                    );

                } catch(e) {}

                if (hasStore) {

                    clearInterval(timer);
                    callback();
                    return;
                }

                if (tries >= 50) {
                    clearInterval(timer);
                }
            }, 200);
    }

    function showBar(message, percent, upsells = []) {

        let bar =
            document.getElementById(
                'free-shipping-bar'
            );

        /*
         * Nog niet aanwezig?
         */

        if (!bar) {

            bar =
                document.createElement(
                    'div'
                );

            bar.id =
                'free-shipping-bar';

bar.innerHTML = `

    <div class="msg"></div>

    <div class="progress">
        <div class="bar"></div>
    </div>

    <div class="upsells-wrapper">

        <button
            class="upsells-arrow prev"
            type="button"
            aria-label="<?php echo esc_attr__(
    'Vorige',
    'tokolariso'
); ?>"
        >
            ‹
        </button>

        <div class="upsells"></div>

        <button
            class="upsells-arrow next"
            type="button"
            aria-label="<?php echo esc_attr__(
    'Volgende',
    'tokolariso'
); ?>"
        >
            ›
        </button>

    </div>
`;

            /*
             * Voor header plaatsen
             */

            const header =
                document.querySelector(
                    '#masthead'
                );

            if (header) {

                header.before(bar);

            } else {

                document.body.prepend(bar);
            } // END else
        } // END if

function updateBarHeight() {

	/* Bewust 2x dezelfde functie om zeker te weten dat
	 *  - de DOM volledig gerenderd is
     *  - de upsells daadwerkelijk zichtbaar zijn
     *  - CSS/layout/herflow klaar is
     * Daarna pas de hoogte wordt gemeten
     */
	
    requestAnimationFrame(function(){

        requestAnimationFrame(function(){

            const height =
                bar.getBoundingClientRect().height;

            document.documentElement.style.setProperty(
                '--fsb-height',
                height + 'px'
            );

        }); // END requestAnimationFrame()

    }); // END requestAnimationFrame()

} // END function updateBarHeight()

updateBarHeight();

        /*
         * Text
         */

        const msg =
            bar.querySelector('.msg');

        msg.textContent =
            message || 'Berekenen';

        /*
         * Progress
         */

        const progress =
            bar.querySelector('.bar');
		
		const upsellWrapper =
            bar.querySelector('.upsells');

        percent =
            parseInt(percent || 0);

        progress.style.width =
            percent + '%';
		
		upsellWrapper.innerHTML = '';
		
		let currentIndex = 0;

if (
    Array.isArray(upsells)
    && upsells.length
) {

    upsells.forEach(product => {

        const productName =
            escapeHtml(product.name);

        const productPrice =
            escapeHtml(product.price);

        const productImage =
            escapeHtml(safeImage(product.image));

        const productId =
            parseInt(product.id || 0, 10);

        if (!productId) {
            return;
        }

        const html = `

            <div class="upsell">

                <img
                    src="${productImage}"
                    alt="${productName}"
                >

                <div class="upsell-info">

                    <div class="upsell-title">
                        ${productName}
                    </div>

                    <div class="upsell-price">
                        ${productPrice}
                    </div>

                </div>

<button
    class="upsell-btn"
    data-product-id="${productId}"
>
    ${fsb_ajax.i18n.add_to_cart}
</button>
            </div>
        `;

        upsellWrapper.insertAdjacentHTML(
            'beforeend',
            html
        );
    });
} // END if Array.isArray(upsells) && upsells.length
		
		/*
 * Hoogte opnieuw berekenen
 */

updateBarHeight();

        if (percent >= 100) {

            progress.classList.add(
                'complete'
            );

        } else {

            progress.classList.remove(
                'complete'
            );
        } // END else
		
		const prevButton =
    bar.querySelector('.upsells-arrow.prev');

const nextButton =
    bar.querySelector('.upsells-arrow.next');

function updateSlider() {

    const cards =
        bar.querySelectorAll('.upsell');

    cards.forEach((card, index) => {

        if (
            index >= currentIndex
            &&
            index < currentIndex + 3
        ) {

            card.style.display = 'flex';

        } else {

            card.style.display = 'none';
        } // END else
    });
} // END function updateSlider()

/*
 * Desktop only
 */

if (
    window.innerWidth > 1024
) {

    updateSlider();

    prevButton.onclick = function() {

        currentIndex = Math.max(
            0,
            currentIndex - 1
        );

        updateSlider();
    };

    nextButton.onclick = function() {

        const maxIndex =
            Math.max(
                0,
                upsells.length - 3
            );

        currentIndex = Math.min(
            maxIndex,
            currentIndex + 1
        );

        updateSlider();
    };

} else {

    prevButton.style.display = 'none';
    nextButton.style.display = 'none';

    /*
     * BELANGRIJK:
     * mobiele cards forceren zichtbaar
     */

    const cards =
        bar.querySelectorAll('.upsell');

    cards.forEach(card => {

        card.style.display = 'flex';
    });
} // END else
		
    } // End function showBar(message, percent, upsells = [])

function pickupSelected() {

    /*
     * Winkelwagenpagina:
     * geen pickup check nodig
     */

    if (isCartPage) {
        return false;
    } // END if

    /*
     * WooCommerce Blocks tabs
     */

    const deliveryOptions = document.querySelectorAll(
        '.wc-block-components-segmented-control__button'
    );

    for (const option of deliveryOptions) {

        const text =
            option.textContent
            ?.toLowerCase()
            ?.trim() || '';

        const active = (

            option.getAttribute(
                'aria-checked'
            ) === 'true'

            ||

            option.classList.contains(
                'is-active'
            )
        );

        if (
            active
            &&
            (
                text.includes('afhalen')
                || text.includes('pickup')
            )
        ) {

            debugLog(
                'PICKUP TAB ACTIVE'
            );

            return true;
        } // END function pickupSelected()
    } // END if

    /*
     * Klassieke radios fallback
     */

    const radios = document.querySelectorAll(
        'input[type="radio"]'
    );

    let shippingValue = '';

    radios.forEach(radio => {

        if (
            radio.value.includes('pickup')
            || radio.value.includes('shipping')
            || radio.value.includes('flat_rate')
            || radio.value.includes('local_pickup')
            || radio.value.includes('wbsng')
        ) {

            if (radio.checked) {

                shippingValue =
                    radio.value;
            } // END if
        } // END function updateBarHeight()
    });

    if (!shippingValue) {
        return false;
    } // END if

    return (
        shippingValue.includes('pickup')
        || shippingValue.includes('local_pickup')
    );
} // END if

    function getCartAddress() {

        let country = 'NL';
        let postcode = '';
        let city = '';

        /*
         * WooCommerce Blocks
         */

        if (
            window.wp &&
            wp.data &&
            wp.data.select('wc/store/cart')
        ) {

            try {

                const cartData =
                    wp.data
                    .select('wc/store/cart')
                    .getCartData();

                if (cartData?.shippingAddress) {

                    country =
                        cartData.shippingAddress.country || 'NL';

                    postcode =
                        cartData.shippingAddress.postcode || '';

                    city =
                        cartData.shippingAddress.city || '';
                } // END if

            } catch(e) {}
        } // END catch

        /*
         * Classic fallback
         */

        if (!postcode) {

            country =
                document.querySelector('#billing_country')?.value
                || document.querySelector('#calc_shipping_country')?.value
                || country;

            postcode =
                document.querySelector('#billing_postcode')?.value
                || document.querySelector('#calc_shipping_postcode')?.value
                || '';

            city =
                document.querySelector('#billing_city')?.value
                || document.querySelector('#calc_shipping_city')?.value
                || '';
        } // END if

        return {
            country,
            postcode,
            city
        };
    } // END try

	if (
    window.wp
    &&
    wp.data
    &&
    wp.data.select('wc/store/cart')
) {

    try {

        const cartStore =
            wp.data
            .select('wc/store/cart');

        const cartData =
            cartStore.getCartData();

    } catch(e) {

if (DEBUG) {

    console.error(
        'STORE API DEBUG ERROR',
        e
    );
} // END if
    } // END catch
} // END try
	
    function loadBar(force = false) {

        debugLog(
            '[FREE SHIPPING] LOAD BAR',
            {
                force,
                loading
            } // END function loadBar()
        );

        if (
            loading
            && !force
        ){
            return;
        } // END function getCartAddress()

        loading = true;

        /*
         * Pickup?
         */

        if (pickupSelected()) {

            hideBar();

            loading = false;

            return;
        } // END if

        const address =
            getCartAddress();

        /*
         * AJAX
         */

        const params =
            new URLSearchParams({

                action:
                    'get_free_shipping_progress',

                country:
                    address.country,

                postcode:
                    address.postcode,

                city:
                    address.city,

                t: Date.now()
            });

        fetch(
            fsb_ajax.url
            + '?'
            + params.toString(),
            {
                cache: 'no-store'
            } // END function showBar()
        )

        

.then(async res => {

    const text = await res.text();

    /*
     * HTTP error?
     */

    if (!res.ok) {

        console.group(
            'FREE SHIPPING AJAX ERROR'
        );

        console.error(
            'HTTP STATUS:',
            res.status
        );

        console.error(
            'RAW RESPONSE:',
            text
        );

        console.groupEnd();

        throw new Error(
            'AJAX HTTP ERROR'
        );
    } // END if

    /*
     * Geen JSON?
     */

    if (
        !text.trim().startsWith('{')
        &&
        !text.trim().startsWith('[')
    ) {

        console.group(
            'FREE SHIPPING INVALID JSON'
        );

        console.error(
            'RAW RESPONSE:',
            text
        );

        console.groupEnd();

        throw new Error(
            'INVALID JSON RESPONSE'
        );
    } // END if

    /*
     * Parse JSON
     */

    try {

        return JSON.parse(text);

    } catch(error) {

        console.group(
            'FREE SHIPPING JSON PARSE ERROR'
        );

        console.error(
            'RAW RESPONSE:',
            text
        );

        console.error(
            'PARSE ERROR:',
            error
        );

        console.groupEnd();

        throw error;
    } // END catch
})

.then(data => {

	if (DEBUG) {
    console.group(
        'FREE SHIPPING DEBUG'
    );

    console.log(
        'FULL AJAX RESPONSE:',
        data
    );

    console.log(
        'TOTAL:',
        data.total
    );

    console.log(
        'MINIMUM:',
        data.minimum
    );

    console.log(
        'REMAINING:',
        data.remaining
    );

    console.log(
        'DEBUG SHIPPING DATA:',
        data.debug_shipping_data
    );

    console.groupEnd();
	} // END if

            /*
             * Geen free shipping?
             */

            if (
                !data
                || data.show === false
            ) {

                setCartCounterValue(0);

                hideBar();

                return;
            } // END try

showBar(
    data.message,
    data.percent,
    data.upsells || []
);
        })

        .catch(error => {

if (DEBUG) {

    console.error(
        '[FREE SHIPPING]',
        error
    );
} // END if

            hideBar();
        })

        .finally(() => {

            loading = false;
        });
    } // END catch

/*
 * INIT
 */

loadBar(true);
	
	/*
 * FORCE WooCommerce Blocks refresh
 * na page load
 */

whenCartStoreReady(function(){

    setTimeout(function(){

        try {

            wp.data
                .dispatch('wc/store/cart')
                .invalidateResolutionForStore();

            if (DEBUG) {

                console.log(
                    'STORE CACHE INVALIDATED'
                );
            } // END if

        } catch(e) {

            debugLog(
                'STORE INVALIDATE ERROR',
                e
            );
        } // END catch

    }, 1200);
});

/*
 * WooCommerce Blocks store subscribe
 */

whenCartStoreReady(function(){

    if (
        storeSubscribed
        ||
        !wp.data.subscribe
    ) {
        return;
    }

    storeSubscribed = true;

    let previousTotals = '';

    wp.data.subscribe(function(){

        try {

            const cart =
                wp.data
                .select('wc/store/cart')
                .getCartData();

            if (!cart?.totals) {
                return;
            } // END if

            const currentTotals =
                JSON.stringify(cart.totals);

            if (
                currentTotals === previousTotals
            ) {
                return;
            } // END try

            previousTotals =
                currentTotals;

            clearTimeout(
                window.fsbStoreTimer
            );

            window.fsbStoreTimer =
                setTimeout(function(){

                    loadBar(true);

                }, 300);

        } catch(e){}
    });
}); // END whenCartStoreReady
	
/*
 * WooCommerce events
 */

if (window.jQuery) {

    jQuery(document.body).on(

        'updated_cart_totals updated_wc_div wc_fragments_refreshed added_to_cart removed_from_cart updated_checkout',

        function(){

            setTimeout(function(){

                loadBar(true);

            }, 500);
        } // END if
    );
} // END function hideBar()

/*
 * Sync bij normale cart updates
 */

if (window.jQuery) {

    jQuery(document.body).on(

        'updated_cart_totals removed_from_cart added_to_cart updated_wc_div',

        function(){

            setTimeout(function(){

                syncSydneyCartCounter();

            }, 300);
        } // END if
    );
} // END function initBar()

/*
 * Alleen WooCommerce fragments observeren
 */

if (window.jQuery) {

    jQuery(document.body).on(

        'wc_fragments_refreshed added_to_cart removed_from_cart updated_checkout',

        function(){

            clearTimeout(
                window.fsbTimer
            );

            window.fsbTimer =
                setTimeout(function(){

                    loadBar(true);

                }, 300); 
        } // END if
    );
} // END if
		
/*
 * Shipping switch
 */

document.body.addEventListener(
    'click',
    function(e){

        /*
         * Zoek shipping methode container
         */

        const shippingWrapper =
            e.target.closest(
                '.wc-block-checkout__shipping-method-option'
            );

        if (!shippingWrapper) {
            return;
        } // END if

        debugLog(
            'SHIPPING CLICK DETECTED'
        );

        /*
         * Kleine delay zodat Blocks
         * checked state kan updaten
         */

        setTimeout(function(){

            const isPickup =
                pickupSelected();

            debugLog(
                'PICKUP:',
                isPickup
            );

            if (isPickup) {

                debugLog(
                    'HIDE BAR'
                );

                hideBar();

            } else {

                debugLog(
                    'SHOW BAR'
                );

                loadBar(true);
            } // END else

        }, 300);
    } // END if
);

	/*
 * ADD TO CART
 */

document.body.addEventListener(
    'click',
    function(e){

        const button =
            e.target.closest('.upsell-btn');

        if (!button) {
            return;
        } // END if

        e.preventDefault();

        const productId =
            button.dataset.productId;

        if (!productId) {
            return;
        } // END if

        button.disabled = true;

        button.innerHTML = '...';

        const formData = new FormData();

        formData.append(
            'action',
            'tokolariso_add_upsell_to_cart'
        );

        formData.append(
            'product_id',
            productId
        );

        fetch(
            fsb_ajax.url,
            {
                method: 'POST',
                body: formData
            } // END if
        )

        .then(async res => {



    const text = await res.text();

    /*
     * HTTP error?
     */

    if (!res.ok) {

        console.group(
            'FREE SHIPPING AJAX ERROR'
        );

        console.error(
            'HTTP STATUS:',
            res.status
        );

        console.error(
            'RAW RESPONSE:',
            text
        );

        console.groupEnd();

        throw new Error(
            'AJAX HTTP ERROR'
        );
    } // END if

    /*
     * Geen JSON?
     */

    if (
        !text.trim().startsWith('{')
        &&
        !text.trim().startsWith('[')
    ) {

        console.group(
            'FREE SHIPPING INVALID JSON'
        );

        console.error(
            'RAW RESPONSE:',
            text
        );

        console.groupEnd();

        throw new Error(
            'INVALID JSON RESPONSE'
        );
    } // END if

    /*
     * Parse JSON
     */

    try {

        return JSON.parse(text);

    } catch(error) {

        console.group(
            'FREE SHIPPING JSON PARSE ERROR'
        );

        console.error(
            'RAW RESPONSE:',
            text
        );

        console.error(
            'PARSE ERROR:',
            error
        );

        console.groupEnd();

        throw error;
    } // END catch
})

        .then(data => {

    if (data.success) {

        button.innerHTML =
            fsb_ajax.i18n.added;

        /*
         * WooCommerce Blocks refresh
         */

        if (
            window.wp
            &&
            wp.data
            &&
            wp.data.dispatch
        ) {

            try {

                wp.data
                    .dispatch('wc/store/cart')
                    .invalidateResolutionForStore();

            } catch(e) {

                console.log(e);
            } // END catch
        } // END try

        /*
         * Classic WooCommerce fallback
         */

/*
 * WooCommerce fragments refresh
 * ZONDER pagina refresh
 */

if (window.jQuery) {

    jQuery.ajax({

        url: fsb_ajax.fragments_url,

        type: 'POST',

        success: function(data) {

            if (
                data
                &&
                data.fragments
            ) {

                Object.keys(data.fragments)
                    .forEach(function(key){

                        jQuery(key).replaceWith(
                            data.fragments[key]
                        );
                    });

                jQuery(document.body)
                    .trigger('wc_fragments_refreshed');
            } // END if
        } // END if
    });
} // END try
		
        /*
         * Free shipping bar refresh
         */

        setTimeout(function(){

            loadBar(true);

        }, 500);
    } // END if
});
});
		
  /*
 * BLOCKS CART OBSERVER
 * Detecteert plus/min updates
 */

const cartObserver = new MutationObserver(function(){

    clearTimeout(window.tokolarisoCartTimer);

    window.tokolarisoCartTimer =
        setTimeout(function(){

if (DEBUG) {

    console.log(
        'BLOCKS CART CHANGE DETECTED'
    );

} // END if (DEBUG)

/*
 * Empty cart detectie
 */

const emptyCart =
    document.querySelector(
        '.wc-block-cart__empty-cart'
    );

if (emptyCart) {

    if (DEBUG) {

        console.log(
            'EMPTY CART DETECTED'
        );

    } // END if (DEBUG)

    /*
     * Header reset
     */

    setCartCounterValue(0);

    hideBar();

    return;

} // END if (emptyCart)

            syncSydneyCartCounter();

            loadBar(true);

        }, 400);

}); /* END MutationObserver */

const cartNode =
    document.querySelector(
        '.wc-block-cart-items'
    );

	if (DEBUG) {
		console.log(
    'CART NODE:',
    cartNode
);
	} // END if
	
if (
    cartNode
    ||
    document.body
) {

    cartObserver.observe(
        cartNode || document.body,
        {
            childList: true,
            subtree: true,
            characterData: true
        } // END if
    );
} // END if
	
	/*
     * Address changes
     */

    let addressTimeout = null;

    [
        'change',
        'input',
        'blur'
    ]

    .forEach(eventType => {

        document.body.addEventListener(
            eventType,
            function(e){

                const target =
                    e.target;

                if (!target) {
                    return;
                } // END if

                const isAddressField = (

                    target.name?.includes('country')
                    || target.name?.includes('postcode')
                    || target.name?.includes('city')
                    || target.name?.includes('state')

                    || target.id?.includes('country')
                    || target.id?.includes('postcode')
                    || target.id?.includes('city')
                    || target.id?.includes('state')
                );

                if (!isAddressField) {
                    return;
                } // END if

                clearTimeout(
                    addressTimeout
                );

                addressTimeout =
                    setTimeout(function(){

                        loadBar(true);

                    }, 1200);
            } // END if
        );
    });

} // END if

if (
    document.readyState === 'complete'
) {

    initBar();

} else {

    window.addEventListener(
        'load',
        initBar
    );
} // END else

})();

</script>

<?php
});


/* =========================================================
 * AJAX HANDLER
========================================================= */

add_action(
    'wp_ajax_get_free_shipping_progress',
    'tokolariso_get_free_shipping_progress'
);

add_action(
    'wp_ajax_nopriv_get_free_shipping_progress',
    'tokolariso_get_free_shipping_progress'
);

function tokolariso_get_free_shipping_progress(){

    /*
     * WooCommerce loaded?
     */

if(
    !class_exists('WooCommerce')
){

    wp_send_json([
        'show' => false
    ]);

    return;
} // END function tokolariso_get_free_shipping_progress()

    /*
     * Cart loaded?
     */

    if(
        is_null(WC()->cart)
        && function_exists('wc_load_cart')
    ){
        wc_load_cart();
    } // END catch

    if(
        !WC()->cart
    ){
        wp_send_json([
            'show' => false
        ]);

        return;
    }

    /*
     * Empty cart?
     */

    if(
        WC()->cart->is_empty()
    ){

        wp_send_json([
            'show' => false
        ]);

        return;
    } // END try


/*
 * Adres uit AJAX
 */

$country =
    sanitize_text_field(
        $_GET['country'] ?? 'NL'
    );

$postcode =
    sanitize_text_field(
        $_GET['postcode'] ?? ''
    );

$city =
    sanitize_text_field(
        $_GET['city'] ?? ''
    );

/*
 * Package opbouwen
 */

$package = [

    'destination' => [

        'country'  => $country,
        'postcode' => $postcode,
        'city'     => $city,
        'state'    => '',
    ]
];

/*
 * Shipping data
 */

$shipping_data =
    tokolariso_get_shipping_data(
        $package
    );

	/*
 * Geen gratis verzending beschikbaar?
 */

if(
    empty($shipping_data['minimum'])
    ||
    (float) $shipping_data['minimum'] <= 0
){

    wp_send_json([
        'show' => false
    ]);

    return;
} // END if

    /*
     * Cart totals
     */

    $totals =
        WC()->cart->get_totals();

    $subtotal =
        isset($totals['subtotal'])
        ? (float) $totals['subtotal']
        : 0;

    $subtotal_tax =
        isset($totals['subtotal_tax'])
        ? (float) $totals['subtotal_tax']
        : 0;

    $total =
        $subtotal
        +
        $subtotal_tax;

    /*
     * Minimum
     */

    $minimum =
        (float) $shipping_data['minimum'];

    /*
     * Remaining
     */

    $remaining =
        max(
            0,
            $minimum - $total
        );

/*
 * SMART UPSELLS ENGINE
 * TOKO LARISO
 * WPML COMPATIBLE
========================================================= */

if(false){

/*
 * WPML taal
 */

$current_language = 'nl';

if (
    has_filter('wpml_current_language')
) {

    $current_language =
        apply_filters(
            'wpml_current_language',
            null
        );
} // END function debugLog()

/*
 * CATEGORIEN
 *
 * Food:
 * Bakmix                    59
 * Drank                     32
 * Ingeblikt fruit          204
 * Ingeblikte groente       208
 * Jellies                  172
 * Ketjap                   157
 * Koffie                    30
 * Kruidenmix                21
 * Meel- en bakproducten   1880
 * Noedels                  224
 * Olie                    2019
 * Ongebakken kroepoek       19
 * Rijst                    177
 * Sambal / saus             38
 * Snacks                    34
 * Specerijen              1857
 * Thee                      35
 *
 * Non-Food:
 * Bamboeproducten         3477
 * Diversen                3478
 * Verzorgingsartikelen    3479
 * Vormen                  3480
 */

/*
 * UPSELL RULES
 */

$upsell_rules = [

    59   => [1880,35,30,32,3480,3477],
    32   => [34,35,30],
    204  => [172],
    208  => [34],
    172  => [3480],
    157  => [21,224,2019,19,177,38,1857],
    3478 => [3477,3479,3480]
];

/*
 * Wederkerig maken
 */

foreach ($upsell_rules as $source => $targets) {

    foreach ($targets as $target) {

        if (
            !isset($upsell_rules[$target])
        ) {
            $upsell_rules[$target] = [];
        } // END foreach

        if (
            !in_array(
                $source,
                $upsell_rules[$target]
            )
        ) {

            $upsell_rules[$target][] =
                $source;
        } // END foreach
    }
}

/*
 * Cart categorieën ophalen
 */

$cart_category_ids = [];

foreach (
    WC()->cart->get_cart() as $cart_item
) {

    $product_id =
        $cart_item['product_id'];

    $terms =
        get_the_terms(
            $product_id,
            'product_cat'
        );

    if (
        empty($terms)
        || is_wp_error($terms)
    ) {
        continue;
    }

    foreach ($terms as $term) {

        $original_id =
            apply_filters(
                'wpml_object_id',
                $term->term_id,
                'product_cat',
                true,
                'nl'
            );

        if ($original_id) {

            $cart_category_ids[] =
                (int) $original_id;
        } // END if
    } // END foreach
}

$cart_category_ids =
    array_unique(
        $cart_category_ids
    );

/*
 * Gerelateerde categorieën
 */

$target_categories = [];

foreach (
    $cart_category_ids as $category_id
) {

    if (
        empty($upsell_rules[$category_id])
    ) {
        continue;
    }

    $target_categories =
        array_merge(
            $target_categories,
            $upsell_rules[$category_id]
        );
}

$target_categories =
    array_unique(
        $target_categories
    );

/*
 * Vertalen naar huidige taal
 */

$wpml_target_categories = [];

foreach (
    $target_categories as $category_id
) {

    $translated_id =
        apply_filters(
            'wpml_object_id',
            $category_id,
            'product_cat',
            true,
            $current_language
        );

    if ($translated_id) {

        $wpml_target_categories[] =
            $translated_id;
    } // END if
}

/*
 * Product IDs reeds in cart
 */

$exclude_ids = [];

foreach (
    WC()->cart->get_cart() as $cart_item
) {

    $exclude_ids[] =
        $cart_item['product_id'];

    if (
        !empty($cart_item['variation_id'])
    ) {

        $exclude_ids[] =
            $cart_item['variation_id'];
    }
}

/*
 * Producten ophalen
 */

$query = new WC_Product_Query([

    'status' => 'publish',

    'limit' => 30,

    'stock_status' => 'instock',

    'exclude' => $exclude_ids,

    'return' => 'objects',

    'tax_query' => [

        [
            'taxonomy' => 'product_cat',

            'field' => 'term_id',

            'terms' => $wpml_target_categories,

            'operator' => 'IN'
        ]
    ]
]);

$products =
    $query->get_products();

/*
 * Variaties toevoegen
 */

$upsell_candidates = [];

foreach ($products as $product) {

    /*
     * Simpel product
     */

    if (
        $product->is_type('simple')
    ) {

        if (
            (float) $product->get_price() <= 0.01
        ) {
            continue;
        } // END foreach

        $upsell_candidates[] =
            $product;
    }

    /*
     * Variabel product
     */

    elseif (
        $product->is_type('variable')
    ) {

        $variations =
            $product->get_available_variations();

        foreach (
            $variations as $variation_data
        ) {

            $variation =
                wc_get_product(
                    $variation_data['variation_id']
                );

            if (
                !$variation
            ) {
                continue;
            }

            if (
                !$variation->is_in_stock()
            ) {
                continue;
            }

            if (
                (float) $variation->get_price()
                <= 0.01
            ) {
                continue;
            }

            $upsell_candidates[] =
                $variation;
        }
    }
}

/*
 * Shuffle
 */

shuffle(
    $upsell_candidates
);

/*
 * Maximaal 15
 */

$upsell_candidates =
    array_slice(
        $upsell_candidates,
        0,
        15
    );

/*
 * Frontend array
 */

$upsells = [];

foreach (
    $upsell_candidates as $product
) {

    $image_id =
        $product->get_image_id();

    if (
        !$image_id
        && $product->get_parent_id()
    ) {

        $image_id =
            get_post_thumbnail_id(
                $product->get_parent_id()
            );
    }

    $upsells[] = [

        'id' => $product->get_id(),

        'name' => $product->get_name(),

'price' => html_entity_decode(
    wp_strip_all_tags(
        wc_price(
            $product->get_price()
        )
    )
),
        'image' =>
            wp_get_attachment_image_url(
                $image_id,
                'thumbnail'
            )
    ];
}

/*
 * Admin-managed rules override the legacy hardcoded candidates.
 * When no rules are saved, tokolariso_fsb_get_upsells() uses the
 * same legacy category mappings as its defaults.
 */

}

$upsells =
    tokolariso_fsb_get_upsells(15);
	
    /*
     * Percentage
     */

/*
 * Percentage veilig berekenen
 */

if(
    $minimum > 0
){

    $percent = min(
        100,
        ($total / $minimum) * 100
    );

}else{

    $percent = 0;
} // END else

    /*
     * Message
     */

    if(
        $remaining > 0
    ){

        $message = sprintf(

            __(
                'Voeg %s toe voor gratis verzending 🚚',
                'tokolariso'
            ),

            wc_price($remaining)
        );

    }else{

        $message =
            __('Je hebt gratis verzending 🎉', 'tokolariso');
    } // END else

    /*
     * Response
     */

wp_send_json([

    'show' => true,

    'percent' => round($percent),

    'message' => html_entity_decode(
        wp_strip_all_tags($message),
        ENT_QUOTES,
        get_bloginfo('charset')
    ),

    'total' => $total,

    'minimum' => $minimum,

    'remaining' => $remaining,
	'upsells'   => $upsells,

    /*
     * DEBUG
     */

    'debug_shipping_data' => $shipping_data
]);
}

/* =========================
   AJAX ADD TO CART
========================= */

add_action(
    'wp_ajax_tokolariso_add_upsell_to_cart',
    'tokolariso_add_upsell_to_cart'
);

add_action(
    'wp_ajax_nopriv_tokolariso_add_upsell_to_cart',
    'tokolariso_add_upsell_to_cart'
);

function tokolariso_add_upsell_to_cart(){

    if(
        is_null(WC()->cart)
        && function_exists('wc_load_cart')
    ){
        wc_load_cart();
    }

    if(
        !WC()->cart
    ){
        wp_send_json([
            'success' => false,
            'message' => 'Winkelwagen niet beschikbaar'
        ]);

        return;
    }

    /*
     * Product ID
     */

    $product_id =
        isset($_POST['product_id'])
        ? absint($_POST['product_id'])
        : 0;

    if(
        !$product_id
    ){

        wp_send_json([
            'success' => false,
            'message' => 'Geen product ID'
        ]);

        return;

    } // END if (!$product_id)

    /*
     * Product ophalen
     */

    $product =
        wc_get_product(
            $product_id
        );

    if(
        !$product
    ){

        wp_send_json([
            'success' => false,
            'message' => 'Product niet gevonden'
        ]);

        return;

    } // END if (!$product)

    /*
     * Variatie?
     */

    $added = false;

    if(
        $product->is_type('variation')
    ){

        $added =
            WC()->cart->add_to_cart(
                $product->get_parent_id(),
                1,
                $product_id,
                $product->get_variation_attributes()
            );

    }else{

        $added =
            WC()->cart->add_to_cart(
                $product_id,
                1
            );

    } // END if variation

    /*
     * Mislukt?
     */

    if(
        !$added
    ){

        wp_send_json([
            'success' => false,
            'message' => 'Toevoegen mislukt'
        ]);

        return;

    } // END if (!$added)

    /*
     * Totals opnieuw berekenen
     */

    WC()->cart->calculate_totals();

    /*
     * Success
     */

    wp_send_json([
        'success' => true
    ]);

} // END function

/* =========================
   STORE API SHIPPING FIX
========================= */

add_filter(
    'woocommerce_store_api_cart_shipping_rates',
    'tokolariso_fix_store_api_shipping_rates',
    9999,
    2
);

function tokolariso_fix_store_api_shipping_rates(
    $shipping_rates,
    $cart
){

    if (
        empty($shipping_rates)
        ||
        !WC()->cart
    ) {
        return $shipping_rates;
    } // END else

    $minimum =
        tokolariso_get_shipping_data()['minimum']
        ?? 0;

    $total =
        WC()->cart->get_subtotal()
        +
        WC()->cart->get_subtotal_tax();

    $is_free =
        $minimum > 0
        &&
        $total >= $minimum;

    if (
        !$is_free
    ) {
        return $shipping_rates;
    } // END function tokolariso_add_upsell_to_cart()

    foreach (
        $shipping_rates as &$package
    ) {

        if (
            empty($package['shipping_rates'])
        ) {
            continue;
        }

        foreach (
            $package['shipping_rates']
            as &$rate
        ) {

            /*
             * Gratis maken
             */

            $rate['price'] = '0';

            if (
                isset($rate['prices'])
            ) {

                $rate['prices']['price'] = '0';

                $rate['prices']['raw_prices']['price']
                    = '0';

                $rate['prices']['raw_prices']['precision']
                    = 6;

            } /* END if prices */

            /*
             * Taxes resetten
             */

            if (
                isset($rate['taxes'])
            ) {

                $rate['taxes'] = [];

            } /* END if taxes */

            /*
             * Label fix
             */

            if (
                !str_contains(
                    strtolower($rate['name'] ?? ''),
                    'gratis'
                )
            ) {

                $rate['name'] .= ' (Gratis)';

            } /* END if label */

        } /* END foreach rate */

    } /* END foreach package */

    return $shipping_rates;

} // END function tokolariso_fix_store_api_shipping_rates()
/* =========================
  SUBTOTALS FIX
========================= */

add_action('wp_footer', function () {
?>
<script>

const DEBUG = false;
	
(function(){

async function waitForBlocksStore(){

    return new Promise(resolve => {

        let tries = 0;

        const timer = setInterval(function(){

            tries++;

            if (
                window.wp
                &&
                wp.data
                &&
                wp.data.select
                &&
                wp.data.select('wc/store/cart')
            ) {

                clearInterval(timer);

                resolve(true);

                return;
            } // END function waitForBlocksStore()

            if (tries > 50) {

                clearInterval(timer);

                resolve(false);
            } // END if

        }, 300);
    });
}

async function injectSubtotalRow(){

    const hasStore =
        await waitForBlocksStore();

    if (!hasStore) {
        return;
    } // END if (!hasStore)

    const totalsWrapper =
        document.querySelector(
            '.wc-block-components-totals-wrapper'
        );

    if (!totalsWrapper) {
        return;
    } // END if (!totalsWrapper)

    /*
     * Native subtotal aanwezig?
     */

    const nativeSubtotal =
        totalsWrapper.querySelector(
            '.wc-block-components-totals-item--subtotal'
        );

    /*
     * Custom subtotal aanwezig?
     */

    const customSubtotal =
        totalsWrapper.querySelector(
            '.tokolariso-subtotal-row'
        );

    /*
     * Shipping row
     */

let hasFreeShipping = false;

try {

    const cart =
        wp.data
        .select('wc/store/cart')
        .getCartData();

    const rates =
        cart?.shippingRates?.[0]
        ?.shipping_rates
        || [];

    hasFreeShipping =
        rates.some(function(rate){

            const price =
                parseInt(
                    rate?.price || 0,
                    10
                );

            return (
    rate?.price === '0'
    ||
    rate?.price === 0
);

        });

} catch(e) {

    if (DEBUG) {

        console.error(
            'FREE SHIPPING DETECTION ERROR',
            e
        );

    } // END if (DEBUG)

} // END try/catch
	
	
    /*
     * GEEN gratis verzending
     */

    if (!hasFreeShipping) {

        /*
         * Cleanup custom subtotal
         */

        if (customSubtotal) {

            customSubtotal.remove();

        } // END if (customSubtotal)

        return;

    } // END if (!hasFreeShipping)

    /*
     * Native subtotal bestaat al
     */

    if (nativeSubtotal) {

        /*
         * Cleanup custom subtotal
         */

        if (customSubtotal) {

            customSubtotal.remove();

        } // END if (customSubtotal)

        return;

    } // END if (nativeSubtotal)


    /*
     * Cart data
     */

    let cart;

    try {

        cart =
            wp.data
            .select('wc/store/cart')
            .getCartData();

    } catch(e) {

        if (DEBUG) {

            console.error(
                'SUBTOTAL ERROR',
                e
            );

        } // END if (DEBUG)

        return;

    } // END try/catch

    if (
        !cart
        ||
        !cart.totals
    ) {
        return;
    } // END if (!cart || !cart.totals)

    /*
     * Subtotal incl. BTW
     */

    const subtotalExclRaw =
        parseInt(
            cart.totals.total_items || 0,
            10
        );

    const subtotalTaxRaw =
        parseInt(
            cart.totals.total_items_tax || 0,
            10
        );

    const subtotalInclRaw =
        subtotalExclRaw
        +
        subtotalTaxRaw;

    /*
     * Currency
     */

    const currency =
        cart.totals.currency_symbol || '€';

    const formattedSubtotal =
        currency
        + ' '
        + (
            subtotalInclRaw / 100
        ).toLocaleString(
            'nl-NL',
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            } // END if
        );

	/*
 * Custom subtotal bestaat al?
 * Dan updaten
 */

if (customSubtotal) {

    const value =
        customSubtotal.querySelector(
            '.wc-block-components-totals-item__value'
        );

    if (value) {

        value.innerHTML =
            formattedSubtotal;

    } // END if (value)

    return;

} // END if (customSubtotal)
	
    /*
     * Row
     */

    const row =
        document.createElement('div');

    row.className =
        'wc-block-components-totals-item tokolariso-subtotal-row';

    row.style.marginBottom =
        '20px';

    row.innerHTML = `

        <div class="wc-block-components-totals-item__label">
            Subtotaal
        </div>

        <div class="wc-block-components-totals-item__value">
            ${formattedSubtotal}
        </div>
    `;

    /*
     * Shipping row opnieuw ophalen
     */

    const latestShippingRow =
        totalsWrapper.querySelector(
            '.wc-block-components-totals-shipping'
        );

    if (latestShippingRow) {

        latestShippingRow.before(
            row
        );

    } else {

        totalsWrapper.prepend(
            row
        );

    } // END if (latestShippingRow)

} // END async function injectSubtotalRow()

/*
 * Init + observer
 */

window.addEventListener(
    'load',
    function(){

        /*
         * Eerste injectie
         */

        setTimeout(function(){

            injectSubtotalRow();

        }, 1500);

        /*
         * Body observer
         * Woo Blocks rendert async
         */

        const bodyObserver =
            new MutationObserver(function(){

                clearTimeout(
                    window.tokolarisoSubtotalTimer
                );

                window.tokolarisoSubtotalTimer =
                    setTimeout(function(){

                        injectSubtotalRow();

                    }, 300);

            }); /* END MutationObserver */

        bodyObserver.observe(
            document.body,
            {
                childList: true,
                subtree: true
            } // END else
        );

    } /* END function */
); /* END window.addEventListener() */

})();
</script>
<?php
}, 999999);

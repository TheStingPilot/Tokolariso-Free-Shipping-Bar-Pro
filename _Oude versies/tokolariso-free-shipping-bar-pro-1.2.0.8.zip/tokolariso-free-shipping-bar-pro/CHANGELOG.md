# Changelog

## 1.2.0.8 - 2026-05-19

- Mobiele Sydney-header bijgestuurd vanuit de plugin-CSS.
- Logo op mobiel begrensd in breedte en hoogte, zodat de menubalk niet meer wordt opgerekt.
- Header-iconen op mobiel laten niet meer onnodig krimpen.
- Beperkt tot `#masthead-mobile` en schermen tot 1024px breed.

## 1.2.0.7 - 2026-05-19

- Progress-AJAX read-only gemaakt zodat verlopen/cached nonces geen `400 Bad Request` meer veroorzaken.
- Add-to-cart nonce-controle behouden voor veiligheid bij schrijfacties.
- `fsb_ajax` naar de footer verplaatst, direct voor de frontend bar-code.
- Dependency-correctie toegevoegd voor de bekende Mollie/Inpsyde handle `inpsyde-blocks`.
- Basis blijft de werkende `1.2.0.3`-lijn, zonder de kapotte externe JS-refactor uit `1.2.0.4/1.2.0.5`.

## 1.2.0.6 - 2026-05-19

- Basis teruggezet naar de werkende `1.2.0.3` uit de zip.
- De `1.2.0.4` script-refactor is niet meegenomen, omdat die AJAX 400-errors veroorzaakte.
- WordPress adminbar-offset toegevoegd voor ingelogde beheerders.
- De free shipping / upsell bar blijft onder `#wpadminbar`.
- De Sydney desktop- en mobiele headers schuiven mee onder de adminbar en pluginbar.
- Changelog toegevoegd aan de build.

## 1.2.0.5 - 2026-05-19

- Gebouwd op `1.2.0.4`; vervangen door `1.2.0.6` vanwege regressie in de frontend bar.

## 1.2.0.4 - 2026-05-18

- Frontend JavaScript verplaatst naar losse assetbestanden.
- WooCommerce Blocks dependencies expliciet gedeclareerd.
- Scripts laden via WordPress enqueue in de footer.
- Defensive checks toegevoegd rond WooCommerce Blocks data.
- Backward compatibility met klassieke WooCommerce checkout behouden.

## 1.2.0.3 - 2026-05-18

- Laatste bekende stabiele basis voor de free shipping / upsell bar.

<?php

if (!defined('ABSPATH')) {
    exit;
} // END if

function tokolariso_fsb_admin_parse_ids(
    $value
){

    if(
        function_exists('tokolariso_fsb_parse_ids')
    ){
        return tokolariso_fsb_parse_ids($value);
    }

    $parts =
        preg_split(
            '/[\s,;|]+/',
            (string) $value
        );

    $ids = [];

    foreach(
        $parts as $part
    ){
        $id = absint($part);

        if(
            $id > 0
        ){
            $ids[] = $id;
        }
    }

    return array_values(array_unique($ids));
}

function tokolariso_fsb_rules_for_export(){

    if(
        function_exists('tokolariso_fsb_get_upsell_rules')
    ){
        return tokolariso_fsb_get_upsell_rules();
    }

    $rules =
        get_option(
            'tokolariso_fsb_upsell_rules',
            []
        );

    return is_array($rules) ? $rules : [];
}

function tokolariso_fsb_settings_page(){

    if(
        !current_user_can('manage_woocommerce')
    ){
        wp_die(
            esc_html__('Je hebt geen rechten voor deze pagina.', 'tokolariso')
        );
    }

    $message = '';

    if(
        (
            isset($_POST['tokolariso_save'])
            || isset($_POST['reset_default_rules'])
        )
        && check_admin_referer(
            'tokolariso_fsb_save_settings',
            'tokolariso_fsb_nonce'
        )
    ){
        update_option(
            'tokolariso_fsb_debug',
            isset($_POST['debug_mode'])
                ? 'yes'
                : 'no'
        );

        if(
            isset($_POST['reset_default_rules'])
        ){
            delete_option('tokolariso_fsb_upsell_rules');
            $message = __('Standaard upsellregels hersteld.', 'tokolariso');
        }elseif(
            !empty($_POST['rules_import'])
        ){
            $decoded =
                json_decode(
                    wp_unslash($_POST['rules_import']),
                    true
                );

            if(
                is_array($decoded)
            ){
                $rules =
                    function_exists('tokolariso_fsb_normalize_upsell_rules')
                    ? tokolariso_fsb_normalize_upsell_rules($decoded)
                    : $decoded;

                update_option(
                    'tokolariso_fsb_upsell_rules',
                    $rules,
                    false
                );

                $message = __('Upsellregels geimporteerd.', 'tokolariso');
            }else{
                $message = __('Import mislukt: JSON is ongeldig.', 'tokolariso');
            }
        }else{
            $posted_rules =
                isset($_POST['upsell_rules'])
                && is_array($_POST['upsell_rules'])
                ? wp_unslash($_POST['upsell_rules'])
                : [];

            $rules = [];

            foreach(
                $posted_rules as $posted_rule
            ){
                if(
                    !is_array($posted_rule)
                ){
                    continue;
                }

                $rule = [
                    'enabled' => !empty($posted_rule['enabled']),
                    'priority' => isset($posted_rule['priority'])
                        ? (int) $posted_rule['priority']
                        : 0,
                    'source_categories' => tokolariso_fsb_admin_parse_ids($posted_rule['source_categories'] ?? ''),
                    'target_categories' => tokolariso_fsb_admin_parse_ids($posted_rule['target_categories'] ?? ''),
                    'source_products' => tokolariso_fsb_admin_parse_ids($posted_rule['source_products'] ?? ''),
                    'target_products' => tokolariso_fsb_admin_parse_ids($posted_rule['target_products'] ?? ''),
                ];

                if(
                    empty($rule['source_categories'])
                    && empty($rule['source_products'])
                    && empty($rule['target_categories'])
                    && empty($rule['target_products'])
                ){
                    continue;
                }

                $rules[] = $rule;
            }

            if(
                function_exists('tokolariso_fsb_normalize_upsell_rules')
            ){
                $rules =
                    tokolariso_fsb_normalize_upsell_rules($rules);
            }

            update_option(
                'tokolariso_fsb_upsell_rules',
                $rules,
                false
            );

            $message = __('Instellingen opgeslagen.', 'tokolariso');
        }
    } // END if

    $debug =
        get_option(
            'tokolariso_fsb_debug',
            'no'
        );

    $rules =
        tokolariso_fsb_rules_for_export();

    $export =
        wp_json_encode(
            $rules,
            JSON_PRETTY_PRINT
        );

    $empty_rows =
        max(
            3,
            8 - count($rules)
        );

?>

<div class="wrap">

    <h1>Toko Lariso Free Shipping Bar PRO</h1>

    <?php if ($message) : ?>
        <div class="notice notice-success is-dismissible">
            <p><?php echo esc_html($message); ?></p>
        </div>
    <?php endif; ?>

    <form method="post">

        <?php wp_nonce_field('tokolariso_fsb_save_settings', 'tokolariso_fsb_nonce'); ?>

        <h2><?php esc_html_e('Algemeen', 'tokolariso'); ?></h2>

        <table class="form-table">

            <tr>

                <th scope="row"><?php esc_html_e('Debug mode', 'tokolariso'); ?></th>

                <td>

                    <label>

                        <input
                            type="checkbox"
                            name="debug_mode"
                            <?php checked($debug, 'yes'); ?>
                        >

                        <?php esc_html_e('Debug logging inschakelen', 'tokolariso'); ?>

                    </label>

                </td>

            </tr>

        </table>

        <h2><?php esc_html_e('Upsellregels', 'tokolariso'); ?></h2>

        <p>
            <?php esc_html_e("Gebruik product- en categorie-IDs, gescheiden door komma's. Hogere prioriteit wint.", 'tokolariso'); ?>
        </p>

        <table class="widefat striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Actief', 'tokolariso'); ?></th>
                    <th><?php esc_html_e('Prioriteit', 'tokolariso'); ?></th>
                    <th><?php esc_html_e('Bron categorieen', 'tokolariso'); ?></th>
                    <th><?php esc_html_e('Doel categorieen', 'tokolariso'); ?></th>
                    <th><?php esc_html_e('Bron producten', 'tokolariso'); ?></th>
                    <th><?php esc_html_e('Doel producten', 'tokolariso'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $row_index = 0;

                foreach(
                    $rules as $rule
                ) :
                    ?>
                    <tr>
                        <td>
                            <input
                                type="checkbox"
                                name="upsell_rules[<?php echo esc_attr($row_index); ?>][enabled]"
                                value="1"
                                <?php checked(!empty($rule['enabled'])); ?>
                            >
                        </td>
                        <td>
                            <input
                                type="number"
                                name="upsell_rules[<?php echo esc_attr($row_index); ?>][priority]"
                                value="<?php echo esc_attr((int) ($rule['priority'] ?? 0)); ?>"
                                style="width:80px"
                            >
                        </td>
                        <td>
                            <input
                                type="text"
                                name="upsell_rules[<?php echo esc_attr($row_index); ?>][source_categories]"
                                value="<?php echo esc_attr(implode(',', $rule['source_categories'] ?? [])); ?>"
                                class="regular-text"
                            >
                        </td>
                        <td>
                            <input
                                type="text"
                                name="upsell_rules[<?php echo esc_attr($row_index); ?>][target_categories]"
                                value="<?php echo esc_attr(implode(',', $rule['target_categories'] ?? [])); ?>"
                                class="regular-text"
                            >
                        </td>
                        <td>
                            <input
                                type="text"
                                name="upsell_rules[<?php echo esc_attr($row_index); ?>][source_products]"
                                value="<?php echo esc_attr(implode(',', $rule['source_products'] ?? [])); ?>"
                                class="regular-text"
                            >
                        </td>
                        <td>
                            <input
                                type="text"
                                name="upsell_rules[<?php echo esc_attr($row_index); ?>][target_products]"
                                value="<?php echo esc_attr(implode(',', $rule['target_products'] ?? [])); ?>"
                                class="regular-text"
                            >
                        </td>
                    </tr>
                    <?php
                    $row_index++;
                endforeach;

                for(
                    $i = 0;
                    $i < $empty_rows;
                    $i++
                ) :
                    ?>
                    <tr>
                        <td>
                            <input
                                type="checkbox"
                                name="upsell_rules[<?php echo esc_attr($row_index); ?>][enabled]"
                                value="1"
                            >
                        </td>
                        <td>
                            <input
                                type="number"
                                name="upsell_rules[<?php echo esc_attr($row_index); ?>][priority]"
                                value="0"
                                style="width:80px"
                            >
                        </td>
                        <td>
                            <input type="text" name="upsell_rules[<?php echo esc_attr($row_index); ?>][source_categories]" class="regular-text">
                        </td>
                        <td>
                            <input type="text" name="upsell_rules[<?php echo esc_attr($row_index); ?>][target_categories]" class="regular-text">
                        </td>
                        <td>
                            <input type="text" name="upsell_rules[<?php echo esc_attr($row_index); ?>][source_products]" class="regular-text">
                        </td>
                        <td>
                            <input type="text" name="upsell_rules[<?php echo esc_attr($row_index); ?>][target_products]" class="regular-text">
                        </td>
                    </tr>
                    <?php
                    $row_index++;
                endfor;
                ?>
            </tbody>
        </table>

        <h2><?php esc_html_e('Import / export', 'tokolariso'); ?></h2>

        <p>
            <?php esc_html_e('Export kopieert de huidige regels als JSON. Plak JSON in import om regels te vervangen.', 'tokolariso'); ?>
        </p>

        <textarea
            readonly
            rows="10"
            class="large-text code"
        ><?php echo esc_textarea($export); ?></textarea>

        <p>
            <textarea
                name="rules_import"
                rows="8"
                class="large-text code"
                placeholder="<?php esc_attr_e('Plak JSON import hier', 'tokolariso'); ?>"
            ></textarea>
        </p>

        <p>

            <button
                class="button button-primary"
                type="submit"
                name="tokolariso_save"
            >
                <?php esc_html_e('Opslaan', 'tokolariso'); ?>
            </button>

            <button
                class="button"
                type="submit"
                name="tokolariso_save"
                value="1"
            >
                <?php esc_html_e('Import uitvoeren', 'tokolariso'); ?>
            </button>

            <button
                class="button"
                type="submit"
                name="reset_default_rules"
                value="1"
                onclick="return confirm('<?php echo esc_js(__('Standaard upsellregels herstellen?', 'tokolariso')); ?>');"
            >
                <?php esc_html_e('Standaardregels herstellen', 'tokolariso'); ?>
            </button>

        </p>

    </form>

</div>

<?php

} // END function tokolariso_fsb_settings_page()
